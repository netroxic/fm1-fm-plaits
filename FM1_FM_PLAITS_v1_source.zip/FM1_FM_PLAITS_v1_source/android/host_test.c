/* Host-side test harness for the Android app: mocks the NDK, drives the real
 * app code (included below), renders frames to PPM and audio to raw float.
 * Build: clang -O1 -DFM1_HOST_TEST -DFPL_SAMPLE_RATE_VARIABLE -Iandroid -Iapp -Isdk/include \
 *        android/host_test.c app/fpl_voice.c -lm -o /tmp/fpl_host */
#define clock_gettime mock_clock_gettime
#include "fpl_app.c"
#undef clock_gettime
static long virtual_ms = 1000;
int mock_clock_gettime(int c, struct timespec *t) { (void)c; t->tv_sec = virtual_ms / 1000; t->tv_nsec = (virtual_ms % 1000) * 1000000; return 0; }

typedef struct FILE FILE;
FILE *fopen(const char *, const char *);
size_t fwrite(const void *, size_t, size_t, FILE *);
int fclose(FILE *);
int printf(const char *, ...);
void *malloc(size_t);
int atoi(const char *);

/* ---- NDK mocks ---- */
struct ANativeWindow { int w, h, bw, bh; uint32_t *pixels; };
struct AInputEvent { int type, action; size_t count; int ids[4]; float xs[4], ys[4]; };
static AAudioStream_dataCallback mock_cb;
static int mock_stream_dummy;
void ANativeActivity_setWindowFlags(ANativeActivity *a, uint32_t add, uint32_t remove) { (void)a; (void)add; (void)remove; }
int32_t ANativeWindow_getWidth(ANativeWindow *w) { return w->bw ? w->bw : w->w; }
int32_t ANativeWindow_getHeight(ANativeWindow *w) { return w->bh ? w->bh : w->h; }
int32_t ANativeWindow_setBuffersGeometry(ANativeWindow *w, int32_t bw, int32_t bh, int32_t f)
{ (void)f; if (!bw) { w->bw = w->w; w->bh = w->h; return 0; } w->bw = bw; w->bh = bh; w->pixels = malloc((size_t)bw * (size_t)bh * 4); return 0; }
int32_t ANativeWindow_lock(ANativeWindow *w, ANativeWindow_Buffer *b, ARect *r)
{ (void)r; b->width = w->bw; b->height = w->bh; b->stride = w->bw; b->format = 2; b->bits = w->pixels; return 0; }
int32_t ANativeWindow_unlockAndPost(ANativeWindow *w) { (void)w; return 0; }
int32_t AInputEvent_getType(const AInputEvent *e) { return e->type; }
int32_t AKeyEvent_getKeyCode(const AInputEvent *e) { (void)e; return AKEYCODE_BACK; }
int32_t AMotionEvent_getAction(const AInputEvent *e) { return e->action; }
size_t AMotionEvent_getPointerCount(const AInputEvent *e) { return e->count; }
int32_t AMotionEvent_getPointerId(const AInputEvent *e, size_t i) { return e->ids[i]; }
float AMotionEvent_getX(const AInputEvent *e, size_t i) { return e->xs[i]; }
float AMotionEvent_getY(const AInputEvent *e, size_t i) { return e->ys[i]; }
void AInputQueue_attachLooper(AInputQueue *q, ALooper *l, int id, ALooper_callbackFunc cb, void *d) { (void)q; (void)l; (void)id; (void)cb; (void)d; }
void AInputQueue_detachLooper(AInputQueue *q) { (void)q; }
int32_t AInputQueue_getEvent(AInputQueue *q, AInputEvent **e) { (void)q; (void)e; return -1; }
int32_t AInputQueue_preDispatchEvent(AInputQueue *q, AInputEvent *e) { (void)q; (void)e; return 0; }
void AInputQueue_finishEvent(AInputQueue *q, AInputEvent *e, int h) { (void)q; (void)e; (void)h; }
ALooper *ALooper_forThread(void) { return (ALooper *)&mock_stream_dummy; }
int ALooper_addFd(ALooper *l, int fd, int id, int ev, ALooper_callbackFunc cb, void *d) { (void)l; (void)fd; (void)id; (void)ev; (void)cb; (void)d; return 1; }
int ALooper_removeFd(ALooper *l, int fd) { (void)l; (void)fd; return 1; }
aaudio_result_t AAudio_createStreamBuilder(AAudioStreamBuilder **b) { *b = (AAudioStreamBuilder *)&mock_stream_dummy; return 0; }
void AAudioStreamBuilder_setDirection(AAudioStreamBuilder *b, int32_t v) { (void)b; (void)v; }
void AAudioStreamBuilder_setFormat(AAudioStreamBuilder *b, int32_t v) { (void)b; (void)v; }
void AAudioStreamBuilder_setChannelCount(AAudioStreamBuilder *b, int32_t v) { (void)b; (void)v; }
void AAudioStreamBuilder_setSampleRate(AAudioStreamBuilder *b, int32_t v) { (void)b; (void)v; }
void AAudioStreamBuilder_setSharingMode(AAudioStreamBuilder *b, int32_t v) { (void)b; (void)v; }
void AAudioStreamBuilder_setPerformanceMode(AAudioStreamBuilder *b, int32_t v) { (void)b; (void)v; }
void AAudioStreamBuilder_setDataCallback(AAudioStreamBuilder *b, AAudioStream_dataCallback cb, void *u) { (void)b; (void)u; mock_cb = cb; }
void AAudioStreamBuilder_setErrorCallback(AAudioStreamBuilder *b, AAudioStream_errorCallback cb, void *u) { (void)b; (void)cb; (void)u; }
aaudio_result_t AAudioStreamBuilder_openStream(AAudioStreamBuilder *b, AAudioStream **s) { (void)b; *s = (AAudioStream *)&mock_stream_dummy; return 0; }
aaudio_result_t AAudioStreamBuilder_delete(AAudioStreamBuilder *b) { (void)b; return 0; }
aaudio_result_t AAudioStream_requestStart(AAudioStream *s) { (void)s; return 0; }
aaudio_result_t AAudioStream_requestStop(AAudioStream *s) { (void)s; return 0; }
aaudio_result_t AAudioStream_close(AAudioStream *s) { (void)s; return 0; }
int32_t AAudioStream_getSampleRate(AAudioStream *s) { (void)s; return 48000; }
int32_t AAudioStream_getFramesPerBurst(AAudioStream *s) { (void)s; return 192; }
aaudio_result_t AAudioStream_setBufferSizeInFrames(AAudioStream *s, int32_t n) { (void)s; return n; }

/* ---- helpers ---- */
static struct ANativeWindow win;
static FILE *audio_file;
static void run_ms(int ms)
{
    static float buf[192 * 2];
    int frames = ms * 48;
    while (frames > 0) {
        int n = frames > 192 ? 192 : frames;
        mock_cb(stream, 0, buf, n);
        if (audio_file) fwrite(buf, sizeof(float), (size_t)n * 2, audio_file);
        frames -= n;
    }
    virtual_ms += ms;
}
static void tick(int ms) { for (int t = 0; t < ms; t += 33) { run_ms(33); on_timer(-1, 0, 0); } }
static void shot(const char *path)
{
    render_frame();
    FILE *f = fopen(path, "wb");
    char header[32] = "P6\n";
    char w[12], h[12];
    number(w, win.bw); number(h, win.bh);
    size_t n = 3;
    for (const char *p = w; *p; ++p) header[n++] = *p;
    header[n++] = ' ';
    for (const char *p = h; *p; ++p) header[n++] = *p;
    memcpy(header + n, "\n255\n", 5); n += 5;
    fwrite(header, 1, n, f);
    for (int i = 0; i < win.bw * win.bh; ++i) {
        uint32_t c = win.pixels[i];
        unsigned char rgb[3] = {(unsigned char)(c & 255), (unsigned char)((c >> 8) & 255), (unsigned char)((c >> 16) & 255)};
        fwrite(rgb, 1, 3, f);
    }
    fclose(f);
}
/* Touch in screen pixels. */
static void touch(int kind, int id, float x, float y)
{
    struct AInputEvent e = {AINPUT_EVENT_TYPE_MOTION, kind, 1, {id}, {x}, {y}};
    handle_motion(&e);
}
static float sx(int cx) { return (float)(cx + org_x) * (float)view_w / (float)fb_w; }
static float sy(int cy) { return (float)(cy + org_y) * (float)view_h / (float)fb_h; }
static void press(int widget)
{
    struct rect r = rects[widget];
    float x = sx(r.x + r.w / 2), y = sy(r.y + r.h / 2);
    touch(AMOTION_EVENT_ACTION_DOWN, 0, x, y);
    tick(66);
    touch(AMOTION_EVENT_ACTION_UP, 0, x, y);
}
static void drag(int widget, int dx)
{
    struct rect r = rects[widget];
    float x = sx(r.x + r.w / 2), y = sy(r.y + r.h / 2);
    touch(AMOTION_EVENT_ACTION_DOWN, 0, x, y);
    for (int i = 1; i <= 10; ++i) touch(AMOTION_EVENT_ACTION_MOVE, 0, sx(r.x + r.w / 2 + dx * i / 10), y);
    touch(AMOTION_EVENT_ACTION_UP, 0, sx(r.x + r.w / 2 + dx), y);
}
int main(int argc, char **argv)
{
    static ANativeActivityCallbacks cbs;
    static ANativeActivity act;
    act.callbacks = &cbs;
    win.w = argc > 1 ? atoi(argv[1]) : 1080;
    win.h = argc > 2 ? atoi(argv[2]) : 2400;
    audio_file = fopen("/tmp/fpl_host_audio.f32", "wb");
    ANativeActivity_onCreate(&act, 0, 0);
    cbs.onNativeWindowCreated(&act, &win);
    tick(1000);
    shot("/tmp/fpl_splash.ppm");
    tick(1400);
    shot("/tmp/fpl_shot0.ppm");
    press(W_PLAY); tick(3000);
    shot("/tmp/fpl_shot1.ppm");
    press(W_ENG_NEXT); press(W_ENG_NEXT); drag(W_TIMB, 120); drag(W_LPG, 150); tick(2500);
    press(W_LFO); tick(2500);
    shot("/tmp/fpl_shot2.ppm");
    press(W_ENG_NAME); tick(100); shot("/tmp/fpl_shot3.ppm");
    press(W_ENGINE0 + 11); tick(2500);           /* STRING */
    press(W_ROOT0 + 2); press(W_NEW); drag(W_DENSITY, 100); tick(2500);
    /* long press LFO -> settings */
    { struct rect r = rects[W_LFO]; float x = sx(r.x + 40), y = sy(r.y + 40);
      touch(AMOTION_EVENT_ACTION_DOWN, 0, x, y); tick(700); touch(AMOTION_EVENT_ACTION_UP, 0, x, y); }
    tick(100); shot("/tmp/fpl_shot4.ppm");
    press(W_CLOSE); press(W_EVOLVE); tick(3000);
    press(W_DIV0 + 3); tick(3000);              /* 2x speed */
    press(W_FX); tick(100); drag(W_RDECAY, 150); press(W_DT0 + 4); shot("/tmp/fpl_fx.ppm");
    press(W_FXCLOSE); tick(3000);
    shot("/tmp/fpl_shot5.ppm");
    fclose(audio_file);
    printf("ok engine=%d overlay=%d bpm=%d playing=%d lfo=%d evolve=%d density=%d root=%d\n",
           g.engine, overlay, g.bpm, atomic_load(&playing), g.mod_on, g.evolve, g.density, g.root);
    return 0;
}
