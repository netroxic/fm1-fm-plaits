/* SPDX-License-Identifier: GPL-3.0-only
 * FM-PLAITS Android effects — by @narti_live.
 * Tempo-synced ping-pong delay into a huge modulated FDN reverb in the spirit
 * of "black hole" space reverbs: 8 modulated delay lines, Hadamard feedback,
 * dark damping, decay up to FREEZE. Runs in the AAudio callback; no libc. */
#include "fpl_fx.h"
#include <stdint.h>

enum { LINES = 8, LINE_SIZE = 16384, DIFF = 4, DIFF_SIZE = 2048, DELAY_SIZE = 131072 };
static float line_buf[LINES][LINE_SIZE];
static float line_lp[LINES];
static unsigned line_pos;
static float mod_phase[LINES];
static float diff_buf[DIFF][DIFF_SIZE];
static unsigned diff_pos;
static float del_buf[2][DELAY_SIZE];
static unsigned del_pos;
static float del_time_smooth = -1.0f, del_lp[2];
static float size_smooth = -1.0f;
static unsigned toggle;

/* Base lengths in milliseconds (mutually prime-ish when converted). */
static const float line_ms[LINES] = {32.43f, 33.71f, 31.07f, 29.63f, 26.61f, 28.27f, 24.77f, 23.29f};
static const float diff_ms[DIFF] = {2.96f, 2.23f, 7.89f, 5.77f};
static const float mod_rate[LINES] = {0.31f, 0.37f, 0.43f, 0.29f, 0.53f, 0.41f, 0.23f, 0.47f};

static inline float clampf(float x, float lo, float hi) { return x < lo ? lo : x > hi ? hi : x; }
static inline float fexp2(float x)
{
    x = clampf(x, -30.0f, 30.0f);
    int i = (int)x;
    if ((float)i > x) --i;
    float f = x - (float)i;
    union { float f; int32_t i; } u;
    u.f = 1.0f + f * (0.6951786f + f * (0.2262058f + f * 0.0782133f));
    u.i += (int32_t)((uint32_t)i << 23);
    return u.f;
}
static inline float soft(float x)
{
    x = clampf(x, -3.0f, 3.0f);
    return x * (27.0f + x * x) / (27.0f + 9.0f * x * x);
}
static inline float read_frac(const float *buf, unsigned mask, unsigned pos, float delay)
{
    float rp = (float)pos - delay;
    while (rp < 0.0f) rp += (float)(mask + 1U);
    unsigned i = (unsigned)rp;
    float f = rp - (float)i;
    float a = buf[i & mask], b = buf[(i + 1U) & mask];
    return a + (b - a) * f;
}

void fx_reset(void)
{
    volatile float *p = &line_buf[0][0];
    for (unsigned i = 0; i < LINES * LINE_SIZE; ++i) p[i] = 0.0f;
    p = &diff_buf[0][0];
    for (unsigned i = 0; i < DIFF * DIFF_SIZE; ++i) p[i] = 0.0f;
    p = &del_buf[0][0];
    for (unsigned i = 0; i < 2U * DELAY_SIZE; ++i) p[i] = 0.0f;
    for (unsigned i = 0; i < LINES; ++i) { line_lp[i] = 0.0f; mod_phase[i] = (float)i * 0.125f; }
    del_lp[0] = del_lp[1] = 0.0f;
    del_time_smooth = size_smooth = -1.0f;
}

void fx_process(float *io, unsigned frames, float sr, const struct fx_params *p)
{
    /* ---------------- delay (ping-pong, tape-like time smoothing) */
    float dmix = clampf(p->del_mix, 0.0f, 1.0f), fb = clampf(p->del_feedback, 0.0f, 0.95f);
    float dtime = clampf(p->del_time * sr, 16.0f, (float)(DELAY_SIZE - 8));
    if (del_time_smooth < 0.0f) del_time_smooth = dtime;
    /* ---------------- reverb parameters (per block) */
    float rmix = clampf(p->rev_mix, 0.0f, 1.0f);
    float size = clampf(p->rev_size, 0.0f, 1.0f);
    if (size_smooth < 0.0f) size_smooth = size;
    float decay = clampf(p->rev_decay, 0.0f, 1.0f), tone = clampf(p->rev_tone, 0.0f, 1.0f);
    int freeze = decay >= 0.99f;
    float t60 = 0.6f * fexp2(decay * 6.5f);                 /* 0.6 s .. ~54 s */
    float damp = 0.06f + tone * tone * 0.9f;
    float ms_to_samples = sr * 0.001f, gains[LINES];
    for (unsigned i = 0; i < LINES; ++i) {
        float len = line_ms[i] * ms_to_samples * (0.35f + (size_smooth < 0.0f ? size : size_smooth) * 2.9f);
        gains[i] = freeze ? 1.0f : fexp2(-9.9658f * len / (t60 * sr));
    }
    for (unsigned n = 0; n < frames; ++n) {
        float l = io[2 * n], r = io[2 * n + 1];
        float anti = (toggle++ & 1U) ? 1e-12f : -1e-12f;
        /* delay */
        del_time_smooth += (dtime - del_time_smooth) * 0.0004f;
        if (dmix > 0.0f || fb > 0.0f) {
            float dl = read_frac(del_buf[0], DELAY_SIZE - 1U, del_pos, del_time_smooth);
            float dr = read_frac(del_buf[1], DELAY_SIZE - 1U, del_pos, del_time_smooth);
            del_lp[0] += (dl - del_lp[0]) * 0.45f;
            del_lp[1] += (dr - del_lp[1]) * 0.45f;
            /* ping-pong: input enters left, the echoes cross sides */
            del_buf[0][del_pos] = soft((l + r) * 0.5f + del_lp[1] * fb) + anti;
            del_buf[1][del_pos] = soft(del_lp[0] * fb) + anti;
            del_pos = (del_pos + 1U) & (DELAY_SIZE - 1U);
            l += dl * dmix;
            r += dr * dmix;
        }
        /* reverb */
        if (rmix > 0.0f || freeze) {
            size_smooth += (size - size_smooth) * 0.00005f;
            float scale = 0.35f + size_smooth * 2.9f;
            float in = freeze ? 0.0f : (l + r) * 0.25f;
            /* input diffusion: 4 allpasses */
            for (unsigned k = 0; k < DIFF; ++k) {
                float d = diff_ms[k] * ms_to_samples * (0.6f + size_smooth);
                float delayed = read_frac(diff_buf[k], DIFF_SIZE - 1U, diff_pos, d);
                float w = in + 0.65f * delayed;
                diff_buf[k][diff_pos] = w;
                in = delayed - 0.65f * w;
            }
            diff_pos = (diff_pos + 1U) & (DIFF_SIZE - 1U);
            float x[LINES];
            for (unsigned i = 0; i < LINES; ++i) {
                mod_phase[i] += mod_rate[i] / sr;
                if (mod_phase[i] >= 1.0f) mod_phase[i] -= 1.0f;
                float tri = mod_phase[i] < 0.5f ? mod_phase[i] * 4.0f - 1.0f : 3.0f - mod_phase[i] * 4.0f;
                float len = line_ms[i] * ms_to_samples * scale + tri * 6.0f * (0.5f + size_smooth);
                len = clampf(len, 8.0f, (float)(LINE_SIZE - 16));
                float v = read_frac(line_buf[i], LINE_SIZE - 1U, line_pos, len);
                line_lp[i] += (v - line_lp[i]) * (freeze ? 1.0f : damp);
                x[i] = line_lp[i] * gains[i];
            }
            /* 8-point Hadamard, normalised */
            for (unsigned h = 1; h < LINES; h <<= 1)
                for (unsigned i = 0; i < LINES; i += h << 1)
                    for (unsigned j = i; j < i + h; ++j) {
                        float a = x[j], b = x[j + h];
                        x[j] = a + b; x[j + h] = a - b;
                    }
            float wl = 0.0f, wr = 0.0f;
            for (unsigned i = 0; i < LINES; ++i) {
                float y = x[i] * 0.35355339f;
                line_buf[i][line_pos] = y + ((i & 1U) ? -in : in) + anti;
                if (i & 1U) wr += y; else wl += y;
            }
            line_pos = (line_pos + 1U) & (LINE_SIZE - 1U);
            float wet = rmix;
            l = l * (1.0f - wet * 0.45f) + wl * wet * 0.9f;
            r = r * (1.0f - wet * 0.45f) + wr * wet * 0.9f;
        }
        io[2 * n] = soft(l * 1.1f) * 0.9f;
        io[2 * n + 1] = soft(r * 1.1f) * 0.9f;
    }
}
