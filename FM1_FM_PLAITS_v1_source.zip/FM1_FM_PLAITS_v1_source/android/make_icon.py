#!/usr/bin/env python3
# SPDX-License-Identifier: GPL-3.0-only
"""Launcher icon: black, yellow waveform over an orange/red low-pass-gate envelope."""
import math, sys
from PIL import Image, ImageDraw
S = 432
im = Image.new("RGB", (S, S), (0, 0, 0))
d = ImageDraw.Draw(im)
def env(t):
    return t / 0.12 if t < 0.12 else math.exp(-(t - 0.12) * 3.2)
pts = [(x, 330 - env((x - 40) / (S - 80)) * 210) for x in range(40, S - 40)]
d.polygon([(40, 330)] + pts + [(S - 40, 330)], fill=(255, 120, 0))
knee = 40 + 0.12 * (S - 80)
d.polygon([(40, 330)] + [p for p in pts if p[0] < knee] + [(knee, 330)], fill=(235, 28, 32))
for x in range(40, S - 40, 2):
    t = (x - 40) / (S - 80)
    y = 200 - math.sin(t * 2 * math.pi * 5) * env(t) * 80
    d.rectangle([x, y - 4, x + 3, y + 4], fill=(255, 214, 0))
d.rectangle([40, 356, S - 40, 372], fill=(255, 255, 255))
im.resize((192, 192), Image.LANCZOS).save(sys.argv[1])
