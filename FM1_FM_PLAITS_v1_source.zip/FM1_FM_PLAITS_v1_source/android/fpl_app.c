/* SPDX-License-Identifier: GPL-3.0-only
 * Generative FM-PLAITS for Android — by @narti_live.
 *
 * A NativeActivity app (no Java): AAudio low-latency output, a software-
 * rendered touch UI and the same Plaits-derived voice (app/fpl_voice.c) and
 * Sting-style generative melody sequencer as the FM-1 firmware.
 * Everything except audio runs on the main thread, driven by its looper:
 * input events plus a 30 Hz timerfd for drawing and the random LFO. */
#include "ndk_min.h"
#include "fpl_voice.h"
#include "fpl_fx.h"
#include <stdatomic.h>

/* ---- the few libc calls we use (bionic) ---- */
void *memset(void *, int, size_t);
void *memcpy(void *, const void *, size_t);
size_t strlen(const char *);
struct timespec { long tv_sec, tv_nsec; };
struct itimerspec { struct timespec it_interval, it_value; };
int clock_gettime(int clock, struct timespec *ts);
int timerfd_create(int clock, int flags);
int timerfd_settime(int fd, int flags, const struct itimerspec *new_value, struct itimerspec *old);
long read(int fd, void *buf, size_t count);
int close(int fd);
#define CLOCK_MONOTONIC 1
#define TFD_NONBLOCK 04000
#define TFD_CLOEXEC 02000000
#define ALOOPER_EVENT_INPUT 1

float fpl_sample_rate = 48000.0f;

static uint32_t now_ms(void)
{
    struct timespec t;
    clock_gettime(CLOCK_MONOTONIC, &t);
    return (uint32_t)(t.tv_sec * 1000 + t.tv_nsec / 1000000);
}
static int clampi(int v, int lo, int hi) { return v < lo ? lo : v > hi ? hi : v; }

/* ======================================================================
 * Generator (same algorithm as the firmware's app/narti.c)
 * ==================================================================== */
enum { STEPS = 16, SCALES = 8 };
static const uint8_t scales[SCALES][13] = {
    {7, 0, 2, 3, 5, 7, 8, 10},  {7, 0, 1, 3, 5, 7, 8, 10}, {7, 0, 2, 3, 5, 7, 9, 10},
    {7, 0, 2, 4, 5, 7, 9, 11},  {5, 0, 3, 5, 7, 10},       {5, 0, 2, 4, 7, 9},
    {6, 0, 2, 4, 6, 8, 10},     {12, 0, 1, 2, 3, 4, 5, 6, 7, 8, 9, 10, 11}};
static const char *const scale_names[SCALES] = {"MINOR", "PHRYG", "DORIAN", "MAJOR", "PENTA-", "PENTA+", "WHOLE", "CHROM"};
static const char *const note_names[12] = {"C", "C#", "D", "D#", "E", "F", "F#", "G", "G#", "A", "A#", "B"};
static const uint8_t intervals[12] = {7, 12, 3, 5, 10, 4, 15, 19, 2, 9, 14, 24};

static struct {
    int root, scale, density, length, accent, slide, spread, octave;
    uint8_t rank[STEPS], note_r[STEPS], oct_r[STEPS], acc_r[STEPS], sld_r[STEPS];
    int engine, harmonics, timbre, morph, freq, lpg; /* 0..100, freq -24..24, lpg -50..50 */
    int live[3];
    int mod_on, mod_speed, mod_depth, evolve;
    int bpm;
    int chance, triplet;
    int speed, rev_mix, rev_size, rev_decay, rev_tone, del_mix, del_div, del_fb;
} g;
static struct { uint8_t rank[STEPS], note_r[STEPS], oct_r[STEPS], acc_r[STEPS], sld_r[STEPS]; int valid; } history;
/* Rendered pattern: written by the UI thread, read by audio (bytes: benign). */
static volatile uint8_t pat_on[STEPS], pat_note[STEPS], pat_acc[STEPS], pat_sld[STEPS];
static volatile int pat_length = 16;
static uint32_t seed = 0x706c6169U;
static uint32_t rnd(void) { seed ^= seed << 13; seed ^= seed >> 17; seed ^= seed << 5; return seed; }
static unsigned rnd_below(unsigned n) { return n ? (rnd() >> 8) % n : 0; }

static unsigned quantize(int scale, int semitone)
{
    int octave = semitone / 12, pc = semitone - octave * 12, best = 0, distance = 99;
    const uint8_t *s = scales[scale];
    for (unsigned i = 1; i <= s[0]; ++i) {
        int d = pc - (int)s[i], a = d < 0 ? -d : d;
        if (a < distance || (a == distance && (int)s[i] > best)) { distance = a; best = s[i]; }
        d = pc - (int)s[i] - 12; a = d < 0 ? -d : d;
        if (a < distance) { distance = a; best = s[i] + 12; }
    }
    return (unsigned)(octave * 12 + best);
}
static void render_pattern(void)
{
    int length = g.length, count = (g.density * length + 8) / 16;
    count = clampi(count, 1, length);
    uint8_t on[STEPS] = {0}, note[STEPS] = {0}, acc[STEPS] = {0}, sld[STEPS] = {0};
    for (int i = 0; i < length; ++i) {
        int better = 0;
        for (int j = 0; j < length; ++j)
            better += g.rank[j] < g.rank[i] || (g.rank[j] == g.rank[i] && j < i);
        on[i] = better < count;
    }
    for (int i = 0; i < length; ++i) {
        if (!on[i]) continue;
        unsigned r = g.note_r[i], semis = 0;
        if (r < 30U + (unsigned)g.spread * 3U / 5U) {
            unsigned usable = 3U + (unsigned)g.spread * 9U / 100U;
            semis = intervals[(r * 7U) % (usable > 12U ? 12U : usable)];
        }
        if (g.oct_r[i] < g.spread / 5) semis += 12;
        note[i] = (uint8_t)clampi(12 * (g.octave + 1) + g.root + (int)quantize(g.scale, (int)semis), 0, 120);
        acc[i] = g.acc_r[i] < g.accent;
    }
    for (int i = 0; i < length; ++i)
        sld[i] = on[i] && on[(i + 1) % length] && length > 1 && g.sld_r[i] < g.slide;
    for (int i = 0; i < STEPS; ++i) { pat_on[i] = on[i]; pat_note[i] = note[i]; pat_acc[i] = acc[i]; pat_sld[i] = sld[i]; }
    pat_length = length;
}
static void remember(void)
{
    memcpy(history.rank, g.rank, STEPS); memcpy(history.note_r, g.note_r, STEPS);
    memcpy(history.oct_r, g.oct_r, STEPS); memcpy(history.acc_r, g.acc_r, STEPS);
    memcpy(history.sld_r, g.sld_r, STEPS); history.valid = 1;
}
static void seeds(void)
{
    for (int i = 0; i < STEPS; ++i) {
        unsigned pos = (unsigned)i & 3U, bias = pos == 0 ? 20 : pos == 2 ? 30 : 50, r = bias + rnd_below(150);
        g.rank[i] = (uint8_t)(r > 255 ? 255 : r);
        g.note_r[i] = (uint8_t)rnd_below(100); g.oct_r[i] = (uint8_t)rnd_below(100);
        g.acc_r[i] = (uint8_t)rnd_below(100); g.sld_r[i] = (uint8_t)rnd_below(100);
    }
    if (rnd_below(100) < 75) { g.rank[0] = 0; g.note_r[0] = 99; }
}
static void generate(void) { seed ^= now_ms() * 2654435761U; remember(); seeds(); render_pattern(); }
static void mutate(int amount)
{
    seed ^= now_ms();
    remember();
    for (int n = 0; n < amount; ++n) {
        int i = (int)rnd_below(STEPS);
        switch (rnd_below(4)) {
        case 0: g.rank[i] = (uint8_t)rnd_below(200); break;
        case 1: g.note_r[i] = (uint8_t)rnd_below(100); break;
        case 2: g.oct_r[i] = (uint8_t)rnd_below(100); break;
        default: g.sld_r[i] = (uint8_t)rnd_below(100); break;
        }
    }
    render_pattern();
}
static void undo(void)
{
    if (!history.valid) return;
    uint8_t t[STEPS];
#define SWAP(f) memcpy(t, g.f, STEPS); memcpy(g.f, history.f, STEPS); memcpy(history.f, t, STEPS)
    SWAP(rank); SWAP(note_r); SWAP(oct_r); SWAP(acc_r); SWAP(sld_r);
#undef SWAP
    render_pattern();
}
static void sound_push(void)
{
    const int *v = g.mod_on ? g.live : &g.harmonics;
    fpl.harmonics = (float)v[0] * 0.01f;
    fpl.timbre = (float)v[1] * 0.01f;
    fpl.morph = (float)v[2] * 0.01f;
    fpl.transpose = (float)(g.freq * 12); /* FREQ steps in octaves */
    fpl.lpg = (float)g.lpg * 0.02f;
    fpl.engine = g.engine;
}
static void random_sound(void)
{
    seed ^= now_ms();
    g.harmonics = (int)rnd_below(101); g.timbre = (int)rnd_below(101); g.morph = (int)rnd_below(101);
    g.lpg = (int)rnd_below(81) - 30;
    g.live[0] = g.harmonics; g.live[1] = g.timbre; g.live[2] = g.morph;
    sound_push();
}
/* Smooth random LFO on harmonics/timbre/morph. */
static struct { int from, to, elapsed, period; } lfo[3];
static void lfo_tick(int dt)
{
    if (!g.mod_on) return;
    /* Exponential speed: 100 ms per glide at 100 down to 90 s at 0. */
    float octs = (float)(100 - g.mod_speed) * 0.098137f;      /* log2(900) * (1 - speed) */
    int whole = (int)octs;
    float frac = octs - (float)whole;
    int base = (int)(100.0f * (float)(1 << whole) * (1.0f + frac * (0.6951786f + frac * (0.2262058f + frac * 0.0782133f))));
    static const int rate[3] = {16, 23, 13};
    for (int t = 0; t < 3; ++t) {
        if (!lfo[t].period || lfo[t].elapsed >= lfo[t].period) {
            lfo[t].from = lfo[t].period ? lfo[t].to : 0;
            lfo[t].to = (int)rnd_below(2049) - 1024;
            lfo[t].elapsed = 0;
            lfo[t].period = clampi((int)((long)base * rate[t] / 16 * (80 + (int)rnd_below(41)) / 100), 40, 200000);
        }
        lfo[t].elapsed = lfo[t].elapsed + dt > lfo[t].period ? lfo[t].period : lfo[t].elapsed + dt;
        int x = lfo[t].elapsed * 1024 / lfo[t].period, s = x * x / 1024 * (3072 - 2 * x) / 1024;
        int cur = lfo[t].from + (lfo[t].to - lfo[t].from) * s / 1024;
        g.live[t] = clampi((&g.harmonics)[t] + cur * 50 * g.mod_depth / (1024 * 100), 0, 100);
    }
    sound_push();
}

/* ======================================================================
 * Audio: AAudio callback, 128-frame blocks, sample-counted sequencer
 * ==================================================================== */
static AAudioStream *stream;
static atomic_int audio_reopen, playing, play_step = -1, bars_done;
static volatile int bpm_shared = 120;
static float block[256];
static int32_t iblock[256];
static unsigned block_pos = 128;
static double step_phase;
static int seq_step = -1, seq_restart;

static void sequencer_block(unsigned frames)
{
    if (!atomic_load(&playing)) { seq_step = -1; return; }
    static const double mult[5] = {1.0 / 16.0, 0.125, 0.25, 0.5, 1.0};
    double sps = fpl_sample_rate * 60.0 / ((double)bpm_shared * 4.0) / mult[clampi(g.speed, 0, 4)];
    if (g.triplet) sps *= 2.0 / 3.0; /* three steps in the time of two */
    if (seq_restart) { seq_restart = 0; seq_step = -1; step_phase = sps; }
    step_phase += frames;
    while (step_phase >= sps) {
        step_phase -= sps;
        int length = pat_length;
        seq_step = (seq_step + 1) % (length > 0 ? length : 16);
        if (seq_step == 0) atomic_fetch_add(&bars_done, 1);
        atomic_store(&play_step, seq_step);
        static uint32_t dice = 0x9e3779b9U;
        dice ^= dice << 13; dice ^= dice >> 17; dice ^= dice << 5;
        if (pat_on[seq_step] && (int)((dice >> 8) % 100U) < g.chance)
            fpl_note(pat_note[seq_step], (pat_acc[seq_step] ? 120U : 84U) | (pat_sld[seq_step] ? 1U : 0U));
    }
}
static int32_t audio_callback(AAudioStream *s, void *user, void *data, int32_t frames)
{
    (void)s; (void)user;
    float *out = (float *)data;
    while (frames > 0) {
        if (block_pos >= 128) {
            sequencer_block(128);
            memset(iblock, 0, sizeof iblock);
            fpl_render_add(iblock);
            for (unsigned i = 0; i < 256; ++i) block[i] = (float)iblock[i] * (1.0f / 8388608.0f);
            static const float quarters[6] = {0.25f, 1.0f / 3.0f, 0.5f, 0.75f, 1.0f, 2.0f};
            struct fx_params fx = {
                (float)g.rev_mix * 0.01f, (float)g.rev_size * 0.01f, (float)g.rev_decay * 0.01f, (float)g.rev_tone * 0.01f,
                (float)g.del_mix * 0.01f, quarters[clampi(g.del_div, 0, 5)] * 60.0f / (float)(bpm_shared > 0 ? bpm_shared : 120),
                (float)g.del_fb * 0.01f};
            fx_process(block, 128, fpl_sample_rate, &fx);
            block_pos = 0;
        }
        unsigned k = 128 - block_pos;
        if ((int32_t)k > frames) k = (unsigned)frames;
        memcpy(out, block + 2 * block_pos, k * 2 * sizeof(float));
        out += 2 * k; block_pos += k; frames -= (int32_t)k;
    }
    return AAUDIO_CALLBACK_RESULT_CONTINUE;
}
static void audio_error(AAudioStream *s, void *user, aaudio_result_t error)
{
    (void)s; (void)user; (void)error;
    atomic_store(&audio_reopen, 1); /* e.g. headphones unplugged: reopen from the main thread */
}
static void audio_close(void)
{
    if (!stream) return;
    AAudioStream_requestStop(stream);
    AAudioStream_close(stream);
    stream = 0;
}
static void audio_open(void)
{
    AAudioStreamBuilder *b = 0;
    if (AAudio_createStreamBuilder(&b) != 0 || !b) return;
    AAudioStreamBuilder_setDirection(b, AAUDIO_DIRECTION_OUTPUT);
    AAudioStreamBuilder_setFormat(b, AAUDIO_FORMAT_PCM_FLOAT);
    AAudioStreamBuilder_setChannelCount(b, 2);
    AAudioStreamBuilder_setSampleRate(b, 48000);
    AAudioStreamBuilder_setSharingMode(b, AAUDIO_SHARING_MODE_SHARED);
    AAudioStreamBuilder_setPerformanceMode(b, AAUDIO_PERFORMANCE_MODE_LOW_LATENCY);
    AAudioStreamBuilder_setDataCallback(b, audio_callback, 0);
    AAudioStreamBuilder_setErrorCallback(b, audio_error, 0);
    if (AAudioStreamBuilder_openStream(b, &stream) != 0) stream = 0;
    AAudioStreamBuilder_delete(b);
    if (!stream) return;
    int32_t rate = AAudioStream_getSampleRate(stream);
    if (rate >= 8000 && rate <= 192000) fpl_sample_rate = (float)rate;
    int32_t burst = AAudioStream_getFramesPerBurst(stream);
    if (burst > 0) AAudioStream_setBufferSizeInFrames(stream, burst * 2);
    AAudioStream_requestStart(stream);
}

/* ======================================================================
 * Drawing: software canvas, 540 x 1140 logical pixels, centred
 * ==================================================================== */
enum { CW = 540, CH = 1324 };
enum {
    C_BLACK = 0x000000, C_WHITE = 0xffffff, C_YELLOW = 0x00d6ff, C_ORANGE = 0x0078ff,
    C_RED = 0x201ceb, C_GRAY = 0x808080, C_DIM = 0x484848, C_CELL = 0x1e1e1e, C_LANE = 0x101010
};
static uint32_t *fb;
static int fb_w, fb_h, fb_stride, org_x, org_y;

static void fill(int x, int y, int w, int h, uint32_t c)
{
    x += org_x; y += org_y;
    if (x < 0) { w += x; x = 0; }
    if (y < 0) { h += y; y = 0; }
    if (x + w > fb_w) w = fb_w - x;
    if (y + h > fb_h) h = fb_h - y;
    if (w <= 0 || h <= 0) return;
    for (int r = 0; r < h; ++r) {
        uint32_t *p = fb + (size_t)(y + r) * (size_t)fb_stride + x;
        for (int i = 0; i < w; ++i) p[i] = c;
    }
}
static const uint8_t font[36][5] = {
    {0x3e, 0x51, 0x49, 0x45, 0x3e}, {0, 0x42, 0x7f, 0x40, 0},       {0x42, 0x61, 0x51, 0x49, 0x46},
    {0x21, 0x41, 0x45, 0x4b, 0x31}, {0x18, 0x14, 0x12, 0x7f, 0x10}, {0x27, 0x45, 0x45, 0x45, 0x39},
    {0x3c, 0x4a, 0x49, 0x49, 0x30}, {0x01, 0x71, 0x09, 0x05, 0x03}, {0x36, 0x49, 0x49, 0x49, 0x36},
    {0x06, 0x49, 0x49, 0x29, 0x1e}, {0x7e, 0x11, 0x11, 0x11, 0x7e}, {0x7f, 0x49, 0x49, 0x49, 0x36},
    {0x3e, 0x41, 0x41, 0x41, 0x22}, {0x7f, 0x41, 0x41, 0x22, 0x1c}, {0x7f, 0x49, 0x49, 0x49, 0x41},
    {0x7f, 0x09, 0x09, 0x09, 0x01}, {0x3e, 0x41, 0x49, 0x49, 0x7a}, {0x7f, 0x08, 0x08, 0x08, 0x7f},
    {0, 0x41, 0x7f, 0x41, 0},       {0x20, 0x40, 0x41, 0x3f, 0x01}, {0x7f, 0x08, 0x14, 0x22, 0x41},
    {0x7f, 0x40, 0x40, 0x40, 0x40}, {0x7f, 0x02, 0x0c, 0x02, 0x7f}, {0x7f, 0x04, 0x08, 0x10, 0x7f},
    {0x3e, 0x41, 0x41, 0x41, 0x3e}, {0x7f, 0x09, 0x09, 0x09, 0x06}, {0x3e, 0x41, 0x51, 0x21, 0x5e},
    {0x7f, 0x09, 0x19, 0x29, 0x46}, {0x46, 0x49, 0x49, 0x49, 0x31}, {0x01, 0x01, 0x7f, 0x01, 0x01},
    {0x3f, 0x40, 0x40, 0x40, 0x3f}, {0x1f, 0x20, 0x40, 0x20, 0x1f}, {0x3f, 0x40, 0x38, 0x40, 0x3f},
    {0x63, 0x14, 0x08, 0x14, 0x63}, {0x07, 0x08, 0x70, 0x08, 0x07}, {0x61, 0x51, 0x49, 0x45, 0x43}};
static const uint8_t punctuation[][6] = {
    {33, 0, 0, 0x5f, 0, 0}, {35, 0x14, 0x7f, 0x14, 0x7f, 0x14}, {37, 0x63, 0x13, 8, 0x64, 0x63},
    {40, 0, 0x1c, 0x22, 0x41, 0}, {41, 0, 0x41, 0x22, 0x1c, 0}, {43, 8, 8, 0x3e, 8, 8},
    {45, 8, 8, 8, 8, 8}, {46, 0, 0x60, 0x60, 0, 0}, {47, 0x60, 0x18, 0x06, 1, 0},
    {58, 0, 0x36, 0x36, 0, 0}, {60, 8, 0x14, 0x22, 0x41, 0}, {62, 0x41, 0x22, 0x14, 8, 0},
    {64, 0x32, 0x49, 0x79, 0x41, 0x3e}, {95, 0x40, 0x40, 0x40, 0x40, 0x40}};
static int text_w(const char *s, int scale) { return (int)strlen(s) * 6 * scale - scale; }
static void text(int x, int y, const char *s, int scale, uint32_t c)
{
    for (; *s; ++s, x += 6 * scale) {
        char ch = *s >= 'a' && *s <= 'z' ? (char)(*s - 32) : *s;
        const uint8_t *shape = 0;
        if (ch >= '0' && ch <= '9') shape = font[ch - '0'];
        else if (ch >= 'A' && ch <= 'Z') shape = font[10 + ch - 'A'];
        else
            for (unsigned i = 0; i < sizeof punctuation / sizeof punctuation[0]; ++i)
                if ((uint8_t)ch == punctuation[i][0]) { shape = punctuation[i] + 1; break; }
        if (!shape) continue;
        for (int col = 0; col < 5; ++col)
            for (int row = 0; row < 7; ++row)
                if (shape[col] & (1U << row)) fill(x + col * scale, y + row * scale, scale, scale, c);
    }
}
static void text_c(int cx, int y, const char *s, int scale, uint32_t c) { text(cx - text_w(s, scale) / 2, y, s, scale, c); }
static void number(char *out, int v)
{
    char t[12]; int n = 0, neg = v < 0;
    unsigned u = neg ? (unsigned)-v : (unsigned)v;
    do { t[n++] = (char)('0' + u % 10); u /= 10; } while (u);
    int k = 0;
    if (neg) out[k++] = '-';
    while (n) out[k++] = t[--n];
    out[k] = 0;
}
static unsigned isqrt(unsigned v) { unsigned r = 0; while ((r + 1) * (r + 1) <= v) ++r; return r; }
static void ig_icon(int x, int y, int size, uint32_t c)
{
    int t = size >= 20 ? 3 : 2, round = size / 4;
    fill(x + round, y, size - 2 * round, t, c);
    fill(x + round, y + size - t, size - 2 * round, t, c);
    fill(x, y + round, t, size - 2 * round, c);
    fill(x + size - t, y + round, t, size - 2 * round, c);
    for (int i = 1; i < round; ++i) {
        int d = round - i, w = round - (int)isqrt((unsigned)(round * round - d * d));
        fill(x + w, y + i, t, 1, c); fill(x + size - w - t, y + i, t, 1, c);
        fill(x + w, y + size - 1 - i, t, 1, c); fill(x + size - w - t, y + size - 1 - i, t, 1, c);
    }
    int cx = x + size / 2, cy = y + size / 2, r = size * 5 / 16, ri = r - t;
    for (int dy = -r; dy <= r; ++dy) {
        int ow = (int)isqrt((unsigned)(r * r - dy * dy));
        int iw = dy * dy < ri * ri ? (int)isqrt((unsigned)(ri * ri - dy * dy)) : -1;
        if (iw < 0) fill(cx - ow, cy + dy, 2 * ow + 1, 1, c);
        else { fill(cx - ow, cy + dy, ow - iw, 1, c); fill(cx + iw + 1, cy + dy, ow - iw, 1, c); }
    }
    int dot = size >= 20 ? 4 : 2;
    fill(x + size - round - dot - t + 1, y + round + t - 1, dot, dot, c);
}

/* ======================================================================
 * Layout and widgets
 * ==================================================================== */
enum {
    W_NONE, W_PLAY, W_BPM, W_ENG_PREV, W_ENG_NEXT, W_ENG_NAME,
    W_HARM, W_TIMB, W_MORPH, W_LPG, W_FREQ,
    W_SCALE, W_OCT_DOWN, W_OCT_UP, W_DENSITY, W_LENGTH,
    W_NEW, W_MUTATE, W_BACK, W_RANDOM, W_LFO, W_EVOLVE,
    W_DIV0, W_DIV4 = W_DIV0 + 4, W_TRIP, W_FX, W_CHANCE, W_REV, W_DEL,
    W_ROOT0, /* .. W_ROOT0 + 11 */
    W_ENGINE0 = W_ROOT0 + 12, /* engine overlay .. + 15 */
    W_SPEED = W_ENGINE0 + 16, W_DEPTH, W_SLIDE, W_CLOSE,
    W_RMIX_O, W_RSIZE, W_RDECAY, W_RTONE, W_DMIX_O, W_DFB, W_DT0, W_DT5 = W_DT0 + 5, W_FXCLOSE,
    W_OVERLAY_BG, W_COUNT
};
struct rect { int x, y, w, h; };
static struct rect rects[W_COUNT];
static int overlay; /* 0 none, 1 engines, 2 LFO settings, 3 FX */
static const char *const div_names[5] = {"/16", "/8", "/4", "/2", "X1"};
static const char *const time_names[6] = {"1/16", "1/8T", "1/8", "3/16", "1/4", "1/2"};
static int splash_on = 1;
static uint32_t splash_start;
static const char *const engine_names[FPL_ENGINES] = {
    "VA", "WAVESHAPE", "FM", "GRAIN", "ADDITIVE", "WAVETABLE", "CHORDS", "VOWEL",
    "SWARM", "NOISE", "PARTICLES", "STRING", "MODAL", "PHASE DIST", "TERRAIN", "CHIPTUNE"};
enum { SLIDER_Y = 336, SLIDER_H = 54, ROLL_Y = 664, ROLL_H = 122, CHANCE_Y = 974, DIV_Y = 1030, FXMIX_Y = 1084, PERF_Y = 1192 };

static void layout(void)
{
    memset(rects, 0, sizeof rects);
    rects[W_BPM] = (struct rect){268, 14, 132, 76};
    rects[W_PLAY] = (struct rect){412, 14, 112, 76};
    rects[W_ENG_PREV] = (struct rect){16, 106, 72, 84};
    rects[W_ENG_NEXT] = (struct rect){452, 106, 72, 84};
    rects[W_ENG_NAME] = (struct rect){96, 106, 348, 84};
    for (int i = 0; i < 5; ++i) rects[W_HARM + i] = (struct rect){16, SLIDER_Y + i * SLIDER_H, 508, SLIDER_H - 8};
    rects[W_SCALE] = (struct rect){150, 612, 150, 44};
    rects[W_OCT_DOWN] = (struct rect){380, 612, 64, 44};
    rects[W_OCT_UP] = (struct rect){452, 612, 72, 44};
    for (int i = 0; i < 12; ++i) rects[W_ROOT0 + i] = (struct rect){16 + i * 43, 806, 39, 50};
    rects[W_DENSITY] = (struct rect){16, 866, 508, 54 - 8};
    rects[W_LENGTH] = (struct rect){16, 920, 508, 54 - 8};
    rects[W_CHANCE] = (struct rect){16, CHANCE_Y, 508, 46};
    for (int i = 0; i < 5; ++i) rects[W_DIV0 + i] = (struct rect){150 + i * 54, DIV_Y, 50, 46};
    rects[W_TRIP] = (struct rect){424, DIV_Y, 50, 46};
    rects[W_FX] = (struct rect){478, DIV_Y, 46, 46};
    rects[W_REV] = (struct rect){16, FXMIX_Y, 508, 46};
    rects[W_DEL] = (struct rect){16, FXMIX_Y + 52, 508, 46};
    for (int i = 0; i < 6; ++i) rects[W_NEW + i] = (struct rect){16 + i * 86, PERF_Y, 80, 88};
    if (overlay == 1) {
        rects[W_OVERLAY_BG] = (struct rect){0, 0, CW, CH};
        for (int i = 0; i < 16; ++i) rects[W_ENGINE0 + i] = (struct rect){16 + (i & 3) * 128, 200 + (i >> 2) * 128, 120, 120};
    } else if (overlay == 2) {
        rects[W_OVERLAY_BG] = (struct rect){0, 0, CW, CH};
        rects[W_SPEED] = (struct rect){16, 360, 508, 70};
        rects[W_DEPTH] = (struct rect){16, 450, 508, 70};
        rects[W_SLIDE] = (struct rect){16, 540, 508, 70};
        rects[W_CLOSE] = (struct rect){140, 660, 260, 90};
    } else if (overlay == 3) {
        rects[W_OVERLAY_BG] = (struct rect){0, 0, CW, CH};
        rects[W_RMIX_O] = (struct rect){16, 200, 508, 60};
        rects[W_RSIZE] = (struct rect){16, 266, 508, 60};
        rects[W_RDECAY] = (struct rect){16, 332, 508, 60};
        rects[W_RTONE] = (struct rect){16, 398, 508, 60};
        rects[W_DMIX_O] = (struct rect){16, 530, 508, 60};
        rects[W_DFB] = (struct rect){16, 596, 508, 60};
        for (int i = 0; i < 6; ++i) rects[W_DT0 + i] = (struct rect){16 + i * 86, 700, 80, 60};
        rects[W_FXCLOSE] = (struct rect){140, 820, 260, 90};
    }
}
static int hit(int x, int y)
{
    int first = overlay == 1 ? W_ENGINE0 : overlay == 2 ? W_SPEED : overlay == 3 ? W_RMIX_O : W_PLAY;
    int last = overlay == 1 ? W_ENGINE0 + 15 : overlay == 2 ? W_CLOSE : overlay == 3 ? W_FXCLOSE : W_ROOT0 + 11;
    for (int w = first; w <= last; ++w) {
        struct rect r = rects[w];
        if (r.w && x >= r.x && x < r.x + r.w && y >= r.y && y < r.y + r.h) return w;
    }
    return overlay ? W_OVERLAY_BG : W_NONE;
}
static void button(int w, const char *label, uint32_t bg, uint32_t fg, int scale)
{
    struct rect r = rects[w];
    fill(r.x, r.y, r.w, r.h, bg);
    text_c(r.x + r.w / 2, r.y + (r.h - 7 * scale) / 2, label, scale, fg);
}
/* Slider: label left, bar right, value inside. centre != 0 draws from the middle. */
static void slider(int w, const char *label, int value, int lo, int hi, int centre, uint32_t color, const char *shown)
{
    struct rect r = rects[w];
    text(r.x + 4, r.y + r.h / 2 - 7, label, 2, C_WHITE);
    int bx = r.x + 150, bw = r.w - 150, by = r.y + 4, bh = r.h - 8;
    fill(bx, by, bw, bh, C_CELL);
    int pos = bw * (value - lo) / (hi - lo);
    if (centre) {
        int mid = bw / 2;
        if (pos >= mid) fill(bx + mid, by, pos - mid, bh, color);
        else fill(bx + pos, by, mid - pos, bh, color == C_ORANGE ? C_RED : color);
        fill(bx + mid - 1, by, 2, bh, C_DIM);
    } else fill(bx, by, pos, bh, color);
    fill(bx + pos - 2, by - 3, 4, bh + 6, C_WHITE);
    char tmp[12];
    if (!shown) { number(tmp, value); shown = tmp; }
    text(bx + bw - text_w(shown, 2) - 8, by + bh / 2 - 7, shown, 2, C_WHITE);
}

/* ======================================================================
 * Frame
 * ==================================================================== */
static int8_t scope_pts[508];
static int scope_ok;
static uint32_t lfo_press_ms;
static int lfo_press_pending;

static void scope_take(void)
{
    if (!fpl_scope_ready) return;
    float peak = 0.0f;
    for (int i = 0; i < 240; ++i) { float v = fpl_scope[i]; if (v < 0) v = -v; if (v > peak) peak = v; }
    float gain = peak > 0.002f ? 0.95f / peak : 0.0f;
    for (int i = 0; i < 508; ++i) {
        int y = (int)(fpl_scope[i * 240 / 508] * gain * 52.0f);
        scope_pts[i] = (int8_t)clampi(y, -54, 54);
    }
    scope_ok = 1;
    fpl_scope_ready = 0;
}
static void draw_splash(void)
{
    uint32_t t = now_ms() - splash_start;
    if (t >= 2200U) { splash_on = 0; return; }
    fill(-org_x, -org_y, fb_w, fb_h, C_BLACK);
    text_c(CW / 2, 400, "FM-PLAITS", 7, C_WHITE);
    text_c(CW / 2, 476, "GENERATIVE", 3, C_ORANGE);
    text_c(CW / 2, 590, "BY: NARTI LIVE", 4, C_YELLOW);
    ig_icon(150, 676, 34, C_WHITE);
    text(196, 685, "@NARTI_LIVE", 3, C_WHITE);
    static const uint32_t bar[3] = {C_YELLOW, C_ORANGE, C_RED};
    unsigned lit = t * 16U / 1500U;
    for (unsigned i = 0; i < 16; ++i) fill(78 + (int)i * 24, 800, 20, 20, i < lit ? bar[i * 3 / 16] : C_CELL);
    /* fade in over 0.3 s and out over the last 0.4 s */
    unsigned alpha = t < 300U ? t * 256U / 300U : t > 1800U ? (2200U - t) * 256U / 400U : 256U;
    if (alpha < 256U)
        for (int y = 0; y < fb_h; ++y) {
            uint32_t *p = fb + (size_t)y * (size_t)fb_stride;
            for (int x = 0; x < fb_w; ++x) {
                uint32_t c = p[x];
                p[x] = ((((c & 0xff00ffU) * alpha) >> 8) & 0xff00ffU) | ((((c & 0x00ff00U) * alpha) >> 8) & 0x00ff00U);
            }
        }
}
static void draw(void)
{
    layout();
    fill(-org_x, -org_y, fb_w, fb_h, C_BLACK);
    char s[48];
    /* Header */
    text(18, 18, "FM-PLAITS", 4, C_WHITE);
    text(18, 58, "GENERATIVE", 2, C_ORANGE);
    if (g.mod_on) text(150, 58, "LFO", 2, C_RED);
    if (g.evolve) text(196, 58, "EVO", 2, C_YELLOW);
    struct rect b = rects[W_BPM];
    fill(b.x, b.y, b.w, b.h, C_CELL);
    number(s, g.bpm);
    text_c(b.x + b.w / 2, b.y + 12, s, 5, C_YELLOW);
    text_c(b.x + b.w / 2, b.y + 54, "< BPM >", 2, C_GRAY);
    int is_playing = atomic_load(&playing);
    struct rect p = rects[W_PLAY];
    fill(p.x, p.y, p.w, p.h, is_playing ? C_RED : C_CELL);
    if (is_playing) fill(p.x + p.w / 2 - 16, p.y + p.h / 2 - 16, 32, 32, C_WHITE);
    else for (int r = 0; r < 40; ++r) { int w = r < 20 ? r + 1 : 40 - r; fill(p.x + p.w / 2 - 14, p.y + p.h / 2 - 20 + r, w * 3 / 2, 1, C_YELLOW); }
    /* Engine selector */
    button(W_ENG_PREV, "<", C_CELL, C_WHITE, 5);
    button(W_ENG_NEXT, ">", C_CELL, C_WHITE, 5);
    struct rect e = rects[W_ENG_NAME];
    text_c(e.x + e.w / 2, e.y + 12, engine_names[g.engine], text_w(engine_names[g.engine], 5) <= e.w ? 5 : 4, C_YELLOW);
    number(s, g.engine + 1);
    int n = (int)strlen(s); s[n++] = '/'; s[n++] = '1'; s[n++] = '6'; memcpy(s + n, "  TAP FOR ALL", 14);
    text_c(e.x + e.w / 2, e.y + 60, s, 2, C_GRAY);
    /* Scope with LPG level */
    fill(16, 204, 508, 120, C_LANE);
    fill(16, 263, 508, 1, C_CELL);
    if (scope_ok) {
        int prev = scope_pts[0];
        for (int x = 0; x < 508; ++x) {
            int y = scope_pts[x], a = prev < y ? prev : y, c = prev < y ? y : prev;
            fill(16 + x, 263 - c, 2, c - a + 2, C_WHITE);
            prev = y;
        }
    }
    int lvl = (int)(fpl_env_view * 508.0f);
    fill(16, 326, clampi(lvl, 0, 508), 4, C_RED);
    /* Sound sliders */
    const int *v = g.mod_on ? g.live : &g.harmonics;
    uint32_t sc = g.mod_on ? C_ORANGE : C_YELLOW;
    slider(W_HARM, "HARMONICS", v[0], 0, 100, 0, sc, 0);
    slider(W_TIMB, "TIMBRE", v[1], 0, 100, 0, sc, 0);
    slider(W_MORPH, "MORPH", v[2], 0, 100, 0, sc, 0);
    const char *lpg = g.lpg > 2 ? "DECAY" : g.lpg < -2 ? "ATTACK" : "PLUCK";
    slider(W_LPG, "LPG", g.lpg, -50, 50, 1, C_ORANGE, lpg);
    char f[12];
    if (g.freq > 0) { f[0] = '+'; number(f + 1, g.freq); } else number(f, g.freq);
    { size_t k = strlen(f); memcpy(f + k, " OCT", 5); }
    slider(W_FREQ, "FREQ", g.freq, -2, 2, 1, C_WHITE, f);
    /* Melody header */
    text(18, 624, "MELODY", 3, C_WHITE);
    button(W_SCALE, scale_names[g.scale], C_CELL, C_YELLOW, 2);
    number(s, g.octave);
    text(310, 627, "OCT", 2, C_GRAY);
    text(352, 624, s, 3, C_WHITE);
    button(W_OCT_DOWN, "-", C_CELL, C_WHITE, 4);
    button(W_OCT_UP, "+", C_CELL, C_WHITE, 4);
    /* Roll */
    int length = pat_length, lo = 127, hi = 0;
    for (int i = 0; i < length; ++i) if (pat_on[i]) { if (pat_note[i] < lo) lo = pat_note[i]; if (pat_note[i] > hi) hi = pat_note[i]; }
    if (lo > hi) lo = hi = 60;
    if (hi - lo < 12) { int pad = (12 - (hi - lo)) / 2; lo = lo > pad ? lo - pad : 0; hi = lo + 12; }
    int span = hi - lo, inner = ROLL_H - 12, step = atomic_load(&play_step);
    for (int i = 0; i < 16; ++i) {
        int x = 16 + i * 32;
        fill(x, ROLL_Y, 28, ROLL_H, i < length ? C_LANE : C_BLACK);
        if (!(i & 3)) fill(x - 2, ROLL_Y, 1, ROLL_H, C_CELL);
        if (i < length) fill(x, ROLL_Y + ROLL_H + 4, 28, 6, pat_on[i] ? (pat_acc[i] ? C_RED : C_ORANGE) : C_CELL);
        if (is_playing && i == step) fill(x, ROLL_Y + ROLL_H + 12, 28, 4, C_WHITE);
    }
    for (int i = 0; i < length; ++i) {
        if (!pat_on[i]) continue;
        int x = 16 + i * 32, y = ROLL_Y + inner - (pat_note[i] - lo) * inner / span;
        fill(x, y, 28, 12, pat_acc[i] ? C_RED : C_YELLOW);
        if (pat_sld[i] && i + 1 < length) {
            int ny = ROLL_Y + inner - (pat_note[i + 1] - lo) * inner / span;
            fill(x + 28, y + 5, 4, 2, C_ORANGE);
            fill(x + 30, (ny < y ? ny : y) + 5, 2, (ny > y ? ny - y : y - ny) + 2, C_ORANGE);
        }
    }
    /* Root keys */
    for (int i = 0; i < 12; ++i) {
        int sharp = note_names[i][1] == '#';
        button(W_ROOT0 + i, note_names[i], i == g.root ? C_YELLOW : sharp ? C_LANE : C_CELL, i == g.root ? C_BLACK : C_WHITE, 2);
    }
    slider(W_DENSITY, "DENSITY", g.density, 1, 16, 0, C_ORANGE, 0);
    slider(W_LENGTH, "LENGTH", g.length, 1, 16, 0, C_ORANGE, 0);
    /* Sequencer speed + FX */
    text(18, DIV_Y + 16, "SPEED", 2, C_WHITE);
    for (int i = 0; i < 5; ++i)
        button(W_DIV0 + i, div_names[i], i == g.speed ? C_YELLOW : C_CELL, i == g.speed ? C_BLACK : C_WHITE, 2);
    button(W_TRIP, "3", g.triplet ? C_RED : C_CELL, C_WHITE, 3);
    text_c(rects[W_TRIP].x + 25, DIV_Y + 48, "TRIPLET", 1, g.triplet ? C_RED : C_DIM);
    button(W_FX, "FX", C_ORANGE, C_BLACK, 2);
    { char pct[8]; number(pct, g.chance); size_t k = strlen(pct); pct[k] = '%'; pct[k + 1] = 0;
      slider(W_CHANCE, "CHANCE", g.chance, 0, 100, 0, C_YELLOW, pct); }
    slider(W_REV, "REVERB", g.rev_mix, 0, 100, 0, C_RED, 0);
    slider(W_DEL, "DELAY", g.del_mix, 0, 100, 0, C_ORANGE, 0);
    /* Performance buttons */
    button(W_NEW, "NEW", C_YELLOW, C_BLACK, 3);
    button(W_MUTATE, "MUTATE", C_CELL, C_WHITE, 2);
    button(W_BACK, "BACK", C_CELL, C_WHITE, 2);
    button(W_RANDOM, "RANDOM", C_ORANGE, C_BLACK, 2);
    button(W_LFO, "LFO", g.mod_on ? C_RED : C_CELL, C_WHITE, 3);
    button(W_EVOLVE, "EVOLVE", g.evolve ? C_YELLOW : C_CELL, g.evolve ? C_BLACK : C_WHITE, 2);
    text_c(16 + 4 * 86 + 40, PERF_Y + 92, "HOLD: SET", 1, C_DIM);
    /* Footer */
    ig_icon(150, 1292, 24, C_YELLOW);
    text(184, 1296, "@NARTI_LIVE", 2, C_YELLOW);
    /* Overlays */
    if (overlay == 1) {
        fill(0, 0, CW, CH, C_BLACK);
        text_c(CW / 2, 120, "ENGINE", 4, C_WHITE);
        for (int i = 0; i < 16; ++i) {
            struct rect r = rects[W_ENGINE0 + i];
            fill(r.x, r.y, r.w, r.h, i == g.engine ? C_YELLOW : C_CELL);
            uint32_t c = i == g.engine ? C_BLACK : C_WHITE;
            number(s, i + 1);
            text_c(r.x + r.w / 2, r.y + 26, s, 3, i == g.engine ? C_BLACK : C_ORANGE);
            text_c(r.x + r.w / 2, r.y + 76, engine_names[i], text_w(engine_names[i], 2) < r.w - 4 ? 2 : 1, c);
        }
        text_c(CW / 2, 740, "TAP AN ENGINE", 2, C_GRAY);
    } else if (overlay == 2) {
        fill(0, 0, CW, CH, C_BLACK);
        text_c(CW / 2, 240, "RANDOM LFO", 4, C_WHITE);
        text_c(CW / 2, 290, "DRIFTS HARMONICS / TIMBRE / MORPH", 1, C_GRAY);
        slider(W_SPEED, "SPEED", g.mod_speed, 0, 100, 0, C_RED, 0);
        slider(W_DEPTH, "DEPTH", g.mod_depth, 0, 100, 0, C_RED, 0);
        slider(W_SLIDE, "SLIDE %", g.slide, 0, 100, 0, C_YELLOW, 0);
        button(W_CLOSE, "DONE", C_YELLOW, C_BLACK, 4);
    } else if (overlay == 3) {
        fill(0, 0, CW, CH, C_BLACK);
        text_c(CW / 2, 110, "FX", 5, C_WHITE);
        text(18, 176, "REVERB  (BLACK HOLE)", 2, C_RED);
        slider(W_RMIX_O, "MIX", g.rev_mix, 0, 100, 0, C_RED, 0);
        slider(W_RSIZE, "SIZE", g.rev_size, 0, 100, 0, C_RED, 0);
        slider(W_RDECAY, "DECAY", g.rev_decay, 0, 100, 0, C_RED, g.rev_decay >= 99 ? "FREEZE" : 0);
        slider(W_RTONE, "TONE", g.rev_tone, 0, 100, 0, C_ORANGE, g.rev_tone < 35 ? "DARK" : g.rev_tone > 70 ? "BRIGHT" : 0);
        text(18, 506, "DELAY  (PING-PONG, SYNCED)", 2, C_ORANGE);
        slider(W_DMIX_O, "MIX", g.del_mix, 0, 100, 0, C_ORANGE, 0);
        slider(W_DFB, "FEEDBACK", g.del_fb, 0, 95, 0, C_ORANGE, 0);
        text(18, 674, "TIME", 2, C_WHITE);
        for (int i = 0; i < 6; ++i)
            button(W_DT0 + i, time_names[i], i == g.del_div ? C_YELLOW : C_CELL, i == g.del_div ? C_BLACK : C_WHITE, 2);
        button(W_FXCLOSE, "DONE", C_YELLOW, C_BLACK, 4);
    }
    if (splash_on) draw_splash();
}

/* ======================================================================
 * Touch
 * ==================================================================== */
enum { MAX_PTR = 10 };
static struct { int id, widget, x0, y0, last_x, moved, value0; uint32_t t0; } ptr[MAX_PTR];
static int view_w = 1, view_h = 1;

static int *slider_target(int w, int *lo, int *hi)
{
    switch (w) {
    case W_HARM: *lo = 0; *hi = 100; return &g.harmonics;
    case W_TIMB: *lo = 0; *hi = 100; return &g.timbre;
    case W_MORPH: *lo = 0; *hi = 100; return &g.morph;
    case W_LPG: *lo = -50; *hi = 50; return &g.lpg;
    case W_FREQ: *lo = -2; *hi = 2; return &g.freq;
    case W_DENSITY: *lo = 1; *hi = 16; return &g.density;
    case W_LENGTH: *lo = 1; *hi = 16; return &g.length;
    case W_SPEED: *lo = 0; *hi = 100; return &g.mod_speed;
    case W_DEPTH: *lo = 0; *hi = 100; return &g.mod_depth;
    case W_SLIDE: *lo = 0; *hi = 100; return &g.slide;
    case W_BPM: *lo = 40; *hi = 250; return &g.bpm;
    case W_REV: case W_RMIX_O: *lo = 0; *hi = 100; return &g.rev_mix;
    case W_DEL: case W_DMIX_O: *lo = 0; *hi = 100; return &g.del_mix;
    case W_CHANCE: *lo = 0; *hi = 100; return &g.chance;
    case W_RSIZE: *lo = 0; *hi = 100; return &g.rev_size;
    case W_RDECAY: *lo = 0; *hi = 100; return &g.rev_decay;
    case W_RTONE: *lo = 0; *hi = 100; return &g.rev_tone;
    case W_DFB: *lo = 0; *hi = 95; return &g.del_fb;
    default: return 0;
    }
}
static void after_value(int w)
{
    if (w == W_HARM || w == W_TIMB || w == W_MORPH) {
        int i = w - W_HARM;
        if (!g.mod_on) g.live[i] = (&g.harmonics)[i];
    }
    if (w == W_DENSITY || w == W_LENGTH || w == W_SLIDE) render_pattern();
    if (w == W_BPM) bpm_shared = g.bpm;
    sound_push();
}
static void tap(int w, int x)
{
    if (overlay == 1) {
        if (w >= W_ENGINE0 && w < W_ENGINE0 + 16) { g.engine = w - W_ENGINE0; sound_push(); overlay = 0; }
        return;
    }
    if (overlay == 2) { if (w == W_CLOSE) overlay = 0; return; }
    if (overlay == 3) {
        if (w == W_FXCLOSE) overlay = 0;
        else if (w >= W_DT0 && w <= W_DT5) g.del_div = w - W_DT0;
        return;
    }
    switch (w) {
    case W_PLAY:
        if (atomic_load(&playing)) atomic_store(&playing, 0);
        else { seq_restart = 1; atomic_store(&bars_done, 0); atomic_store(&playing, 1); }
        break;
    case W_BPM: g.bpm = clampi(g.bpm + (x < rects[W_BPM].x + rects[W_BPM].w / 2 ? -1 : 1), 40, 250); bpm_shared = g.bpm; break;
    case W_ENG_PREV: g.engine = (g.engine + FPL_ENGINES - 1) % FPL_ENGINES; sound_push(); break;
    case W_ENG_NEXT: g.engine = (g.engine + 1) % FPL_ENGINES; sound_push(); break;
    case W_ENG_NAME: overlay = 1; break;
    case W_SCALE: g.scale = (g.scale + 1) % SCALES; render_pattern(); break;
    case W_OCT_DOWN: g.octave = clampi(g.octave - 1, 1, 5); render_pattern(); break;
    case W_OCT_UP: g.octave = clampi(g.octave + 1, 1, 5); render_pattern(); break;
    case W_NEW: generate(); break;
    case W_MUTATE: mutate(3); break;
    case W_BACK: undo(); break;
    case W_RANDOM: random_sound(); break;
    case W_LFO: g.mod_on ^= 1; memset(lfo, 0, sizeof lfo); g.live[0] = g.harmonics; g.live[1] = g.timbre; g.live[2] = g.morph; sound_push(); break;
    case W_EVOLVE: g.evolve ^= 1; atomic_store(&bars_done, 0); break;
    case W_FX: overlay = 3; break;
    case W_TRIP: g.triplet ^= 1; break;
    default:
        if (w >= W_ROOT0 && w < W_ROOT0 + 12) { g.root = w - W_ROOT0; render_pattern(); }
        else if (w >= W_DIV0 && w <= W_DIV4) g.speed = w - W_DIV0;
        break;
    }
}
static void pointer_down(int id, int x, int y)
{
    if (splash_on) { splash_on = 0; return; } /* a tap skips the intro */
    layout();
    for (int i = 0; i < MAX_PTR; ++i)
        if (!ptr[i].widget) {
            int w = hit(x, y), lo, hi;
            int *t = slider_target(w, &lo, &hi);
            ptr[i].id = id; ptr[i].widget = w ? w : -1; ptr[i].x0 = ptr[i].last_x = x; ptr[i].y0 = y;
            ptr[i].moved = 0; ptr[i].value0 = t ? *t : 0; ptr[i].t0 = now_ms();
            if (w == W_LFO) { lfo_press_pending = 1; lfo_press_ms = ptr[i].t0; }
            return;
        }
}
static void pointer_move(int id, int x, int y)
{
    (void)y;
    for (int i = 0; i < MAX_PTR; ++i)
        if (ptr[i].widget && ptr[i].id == id) {
            int dx = x - ptr[i].x0;
            if (dx > 12 || dx < -12) ptr[i].moved = 1;
            int lo, hi, *t = slider_target(ptr[i].widget, &lo, &hi);
            if (t && ptr[i].moved) {
                int width = ptr[i].widget == W_BPM ? 4 * (hi - lo) : 358;
                int v = clampi(ptr[i].value0 + dx * (hi - lo) / width, lo, hi);
                if (v != *t) { *t = v; after_value(ptr[i].widget); }
            }
            ptr[i].last_x = x;
        }
}
static void pointer_up(int id, int cancel)
{
    for (int i = 0; i < MAX_PTR; ++i)
        if (ptr[i].widget && ptr[i].id == id) {
            int w = ptr[i].widget;
            if (w == W_LFO) {
                if (lfo_press_pending && !cancel && !ptr[i].moved) tap(w, ptr[i].x0);
                lfo_press_pending = 0;
            } else if (!cancel && !ptr[i].moved && w > 0) {
                int lo, hi;
                if (!slider_target(w, &lo, &hi) || w == W_BPM) tap(w, ptr[i].x0);
            }
            ptr[i].widget = 0;
        }
}
static int to_canvas_x(float x) { return (int)(x * (float)fb_w / (float)view_w) - org_x; }
static int to_canvas_y(float y) { return (int)(y * (float)fb_h / (float)view_h) - org_y; }
static int handle_motion(const AInputEvent *e)
{
    int32_t action = AMotionEvent_getAction(e), kind = action & AMOTION_EVENT_ACTION_MASK;
    size_t index = (size_t)((action & AMOTION_EVENT_ACTION_POINTER_INDEX_MASK) >> AMOTION_EVENT_ACTION_POINTER_INDEX_SHIFT);
    size_t count = AMotionEvent_getPointerCount(e);
    switch (kind) {
    case AMOTION_EVENT_ACTION_DOWN:
    case AMOTION_EVENT_ACTION_POINTER_DOWN:
        if (index < count)
            pointer_down(AMotionEvent_getPointerId(e, index), to_canvas_x(AMotionEvent_getX(e, index)), to_canvas_y(AMotionEvent_getY(e, index)));
        break;
    case AMOTION_EVENT_ACTION_MOVE:
        for (size_t i = 0; i < count; ++i)
            pointer_move(AMotionEvent_getPointerId(e, i), to_canvas_x(AMotionEvent_getX(e, i)), to_canvas_y(AMotionEvent_getY(e, i)));
        break;
    case AMOTION_EVENT_ACTION_UP:
    case AMOTION_EVENT_ACTION_POINTER_UP:
        if (index < count) pointer_up(AMotionEvent_getPointerId(e, index), 0);
        break;
    case AMOTION_EVENT_ACTION_CANCEL:
        for (int i = 0; i < MAX_PTR; ++i) if (ptr[i].widget) pointer_up(ptr[i].id, 1);
        break;
    }
    return 1;
}

/* ======================================================================
 * NativeActivity plumbing (main thread only)
 * ==================================================================== */
static ANativeWindow *window;
static AInputQueue *input_queue;
static ALooper *main_looper;
static int timer_fd = -1;
static uint32_t last_tick;

static void configure_window(void)
{
    if (!window) return;
    ANativeWindow_setBuffersGeometry(window, 0, 0, 0); /* back to the real window size */
    view_w = ANativeWindow_getWidth(window);
    view_h = ANativeWindow_getHeight(window);
    if (view_w <= 0 || view_h <= 0) { view_w = view_h = 1; return; }
    /* Buffer keeps the screen's aspect; the 540x1140 canvas is centred in it. */
    if ((long)CH * view_w > (long)CW * view_h) { fb_h = CH; fb_w = (int)((long)CH * view_w / view_h); }
    else { fb_w = CW; fb_h = (int)((long)CW * view_h / view_w); }
    org_x = (fb_w - CW) / 2;
    org_y = (fb_h - CH) / 2;
    ANativeWindow_setBuffersGeometry(window, fb_w, fb_h, WINDOW_FORMAT_RGBX_8888);
}
static void render_frame(void)
{
    if (!window) return;
    ANativeWindow_Buffer buffer;
    if (ANativeWindow_lock(window, &buffer, 0) != 0) return;
    if (buffer.width != fb_w || buffer.height != fb_h) { ANativeWindow_unlockAndPost(window); configure_window(); return; }
    fb = (uint32_t *)buffer.bits;
    fb_stride = buffer.stride;
    scope_take();
    draw();
    ANativeWindow_unlockAndPost(window);
    fb = 0;
}
static int on_timer(int fd, int events, void *data)
{
    (void)events; (void)data;
    uint64_t expirations;
    while (read(fd, &expirations, sizeof expirations) > 0) {}
    uint32_t now = now_ms();
    int dt = (int)(now - last_tick);
    last_tick = now;
    if (dt > 200) dt = 200;
    lfo_tick(dt);
    if (lfo_press_pending && now - lfo_press_ms >= 550U) { lfo_press_pending = 0; overlay = 2; }
    if (g.evolve && atomic_load(&bars_done) >= 8) { atomic_store(&bars_done, 0); mutate(2); }
    if (atomic_exchange(&audio_reopen, 0)) { audio_close(); audio_open(); }
    render_frame();
    return 1;
}
static int on_input(int fd, int events, void *data)
{
    (void)fd; (void)events; (void)data;
    AInputEvent *event = 0;
    while (input_queue && AInputQueue_getEvent(input_queue, &event) >= 0) {
        if (AInputQueue_preDispatchEvent(input_queue, event)) continue;
        int handled = 0;
        int32_t type = AInputEvent_getType(event);
        if (type == AINPUT_EVENT_TYPE_MOTION) handled = handle_motion(event);
        else if (type == AINPUT_EVENT_TYPE_KEY && AKeyEvent_getKeyCode(event) == AKEYCODE_BACK && overlay) {
            overlay = 0; handled = 1;
        }
        AInputQueue_finishEvent(input_queue, event, handled);
    }
    return 1;
}
static void on_window_created(ANativeActivity *a, ANativeWindow *w) { (void)a; window = w; configure_window(); render_frame(); }
static void on_window_destroyed(ANativeActivity *a, ANativeWindow *w) { (void)a; (void)w; window = 0; }
static void on_window_resized(ANativeActivity *a, ANativeWindow *w) { (void)a; window = w; configure_window(); }
static void on_redraw(ANativeActivity *a, ANativeWindow *w) { (void)a; (void)w; render_frame(); }
static void on_input_created(ANativeActivity *a, AInputQueue *q)
{
    (void)a;
    input_queue = q;
    AInputQueue_attachLooper(q, main_looper, 1, on_input, 0);
}
static void on_input_destroyed(ANativeActivity *a, AInputQueue *q)
{
    (void)a;
    AInputQueue_detachLooper(q);
    input_queue = 0;
}
static void on_destroy(ANativeActivity *a)
{
    (void)a;
    audio_close();
    if (timer_fd >= 0) { ALooper_removeFd(main_looper, timer_fd); close(timer_fd); timer_fd = -1; }
}
static void on_resume(ANativeActivity *a) { (void)a; if (!stream) audio_open(); }

__attribute__((visibility("default"))) void ANativeActivity_onCreate(ANativeActivity *activity, void *saved, size_t saved_size)
{
    (void)saved; (void)saved_size;
    activity->callbacks->onNativeWindowCreated = on_window_created;
    activity->callbacks->onNativeWindowDestroyed = on_window_destroyed;
    activity->callbacks->onNativeWindowResized = on_window_resized;
    activity->callbacks->onNativeWindowRedrawNeeded = on_redraw;
    activity->callbacks->onInputQueueCreated = on_input_created;
    activity->callbacks->onInputQueueDestroyed = on_input_destroyed;
    activity->callbacks->onDestroy = on_destroy;
    activity->callbacks->onResume = on_resume;
    ANativeActivity_setWindowFlags(activity, AWINDOW_FLAG_KEEP_SCREEN_ON | AWINDOW_FLAG_FULLSCREEN, 0);
    main_looper = ALooper_forThread();
    static int initialized;
    if (!initialized) {
        initialized = 1;
        fpl_voice_init();
        g.root = 9; g.scale = 0; g.density = 9; g.length = 16; g.accent = 25; g.slide = 15; g.spread = 55; g.octave = 3;
        g.engine = 0; g.harmonics = 45; g.timbre = 40; g.morph = 35; g.freq = 0; g.lpg = 12;
        g.mod_speed = 30; g.mod_depth = 50; g.bpm = 120;
        g.chance = 100; g.triplet = 0;
        g.speed = 4; g.rev_mix = 30; g.rev_size = 70; g.rev_decay = 60; g.rev_tone = 35;
        g.del_mix = 20; g.del_div = 3; g.del_fb = 45;
        fx_reset();
        splash_start = now_ms();
        g.live[0] = g.harmonics; g.live[1] = g.timbre; g.live[2] = g.morph;
        bpm_shared = g.bpm;
        seed ^= now_ms() * 2654435761U;
        seeds();
        render_pattern();
        sound_push();
        fpl.active = 1;
    }
    if (!stream) audio_open();
    timer_fd = timerfd_create(CLOCK_MONOTONIC, TFD_NONBLOCK | TFD_CLOEXEC);
    if (timer_fd >= 0) {
        struct itimerspec spec = {{0, 33333333}, {0, 33333333}};
        timerfd_settime(timer_fd, 0, &spec, 0);
        ALooper_addFd(main_looper, timer_fd, 2, ALOOPER_EVENT_INPUT, on_timer, 0);
    }
    last_tick = now_ms();
}
