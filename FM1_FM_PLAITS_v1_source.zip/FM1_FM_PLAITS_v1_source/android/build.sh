#!/usr/bin/env bash
# SPDX-License-Identifier: GPL-3.0-only
# Build the Generative FM-PLAITS Android app (NativeActivity, no Java/SDK needed).
# Needs: clang + ld.lld (LLVM 15+), python3 with "cryptography" and "Pillow".
# Output: build/android/FM-PLAITS.apk  (arm64-v8a + x86_64, minSdk 26)
set -euo pipefail
root="$(cd "$(dirname "$0")/.." && pwd)"
out="$root/build/android"; mkdir -p "$out"
cres="$(clang -print-resource-dir)/include"
mkdir -p "$out/inc"
printf '#pragma once\nfloat sinf(float); float fabsf(float); float cosf(float);\n' > "$out/inc/math.h"

declare -A SYMS=(
 [libandroid.so]="ANativeActivity_setWindowFlags ANativeWindow_getHeight ANativeWindow_getWidth ANativeWindow_lock ANativeWindow_setBuffersGeometry ANativeWindow_unlockAndPost AInputEvent_getType AInputQueue_attachLooper AInputQueue_detachLooper AInputQueue_finishEvent AInputQueue_getEvent AInputQueue_preDispatchEvent AKeyEvent_getKeyCode ALooper_addFd ALooper_forThread ALooper_removeFd AMotionEvent_getAction AMotionEvent_getPointerCount AMotionEvent_getPointerId AMotionEvent_getX AMotionEvent_getY"
 [libaaudio.so]="AAudioStreamBuilder_delete AAudioStreamBuilder_openStream AAudioStreamBuilder_setChannelCount AAudioStreamBuilder_setDataCallback AAudioStreamBuilder_setDirection AAudioStreamBuilder_setErrorCallback AAudioStreamBuilder_setFormat AAudioStreamBuilder_setPerformanceMode AAudioStreamBuilder_setSampleRate AAudioStreamBuilder_setSharingMode AAudioStream_close AAudioStream_getFramesPerBurst AAudioStream_getSampleRate AAudioStream_requestStart AAudioStream_requestStop AAudioStream_setBufferSizeInFrames AAudio_createStreamBuilder"
 [libc.so]="clock_gettime close memcpy memset read strlen timerfd_create timerfd_settime"
 [libm.so]="sinf fabsf"
)
for abi in arm64-v8a x86_64; do
  case $abi in arm64-v8a) target=aarch64-linux-android26;; x86_64) target=x86_64-linux-android26;; esac
  d="$out/$abi"; mkdir -p "$d/stubs"
  # Link-time stubs for the system libraries (the real ones are on the phone).
  for lib in "${!SYMS[@]}"; do
    : > "$d/stubs/$lib.c"
    for s in ${SYMS[$lib]}; do echo "void $s(void) {}" >> "$d/stubs/$lib.c"; done
    clang --target=$target -fPIC -ffreestanding -nostdlib -shared -fuse-ld=lld -Wl,-soname,$lib -o "$d/stubs/$lib" "$d/stubs/$lib.c"
  done
  flags=(--target=$target -O2 -fPIC -ffreestanding -nostdinc -isystem "$cres" -I"$out/inc" -I"$root/android" -I"$root/app"
         -I"$root/sdk/include" -DFM1_HOST_TEST -DFPL_SAMPLE_RATE_VARIABLE -fno-stack-protector -fvisibility=hidden
         -ffunction-sections -fdata-sections -Wall -Wextra -Werror)
  clang "${flags[@]}" -c "$root/android/fpl_app.c" -o "$d/fpl_app.o"
  clang "${flags[@]}" -c "$root/app/fpl_voice.c" -o "$d/fpl_voice.o"
  clang "${flags[@]}" -c "$root/android/fpl_fx.c" -o "$d/fpl_fx.o"
  ld.lld -shared -soname libfmplaits.so --hash-style=both -z noexecstack -z relro -z now -z max-page-size=16384 \
    --no-undefined --gc-sections -o "$d/libfmplaits.so" "$d/fpl_app.o" "$d/fpl_voice.o" "$d/fpl_fx.o" \
    -L"$d/stubs" -l:libandroid.so -l:libaaudio.so -l:libm.so -l:libc.so
  llvm-strip --strip-unneeded "$d/libfmplaits.so"
done
python3 "$root/android/make_icon.py" "$out/icon.png"
python3 "$root/android/build_apk.py" "$out" "$out/icon.png" "$out/FM-PLAITS.apk" "${FPL_KEY:-$out/release-key.pem}"
echo "APK: $out/FM-PLAITS.apk"
