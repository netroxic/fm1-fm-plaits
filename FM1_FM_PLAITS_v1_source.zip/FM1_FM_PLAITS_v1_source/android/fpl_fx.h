/* SPDX-License-Identifier: GPL-3.0-only
 * FM-PLAITS Android effects: synced ping-pong delay + "black hole" FDN reverb. */
#ifndef FPL_FX_H
#define FPL_FX_H
struct fx_params {
    float rev_mix, rev_size, rev_decay, rev_tone; /* 0..1, decay 1 = FREEZE */
    float del_mix, del_time, del_feedback;        /* time in seconds */
};
void fx_reset(void);
void fx_process(float *stereo, unsigned frames, float sample_rate, const struct fx_params *p);
#endif
