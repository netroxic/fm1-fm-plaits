#!/usr/bin/env python3
# SPDX-License-Identifier: GPL-3.0-only
"""Build the Generative FM-PLAITS Android APK without the Android SDK.

Writes a binary AndroidManifest.xml (AXML), a one-entry resources.arsc for
the launcher icon, packs the native library, aligns the archive and signs it
with APK Signature Scheme v2 (RSA-2048 / SHA-256).

usage: build_apk.py <libfmplaits.so | dir with <abi>/libfmplaits.so> <icon.png> <out.apk> [key.pem]
"""
import hashlib
import os
import struct
import sys
import zlib

from cryptography import x509
from cryptography.hazmat.primitives import hashes, serialization
from cryptography.hazmat.primitives.asymmetric import padding, rsa
from cryptography.x509.oid import NameOID
import datetime

PACKAGE = "com.nartilive.fmplaits"
LABEL = "FM-PLAITS"
LIB = "fmplaits"
ANDROID_NS = "http://schemas.android.com/apk/res/android"

# android.R.attr ids
ATTR = {
    "label": 0x01010001, "icon": 0x01010002, "name": 0x01010003, "hasCode": 0x0101000C,
    "exported": 0x01010010, "screenOrientation": 0x0101001E, "configChanges": 0x0101001F,
    "value": 0x01010024, "minSdkVersion": 0x0101020C, "versionCode": 0x0101021B,
    "versionName": 0x0101021C, "targetSdkVersion": 0x01010270, "extractNativeLibs": 0x010104EA,
}
T_REF, T_STRING, T_INT_DEC, T_BOOL = 0x01, 0x03, 0x10, 0x12
ICON_ID = 0x7F010000


# ----------------------------------------------------------------- string pool
def string_pool(strings):
    """UTF-16 string pool chunk."""
    offsets, data = [], b""
    for s in strings:
        offsets.append(len(data))
        enc = s.encode("utf-16-le")
        data += struct.pack("<H", len(s)) + enc + b"\x00\x00"
    while len(data) % 4:
        data += b"\x00"
    header_size = 28
    strings_start = header_size + 4 * len(strings)
    size = strings_start + len(data)
    return struct.pack("<HHIIIIII", 0x0001, header_size, size, len(strings), 0, 0, strings_start, 0) + \
        b"".join(struct.pack("<I", o) for o in offsets) + data


# ----------------------------------------------------------------- AXML
def axml(tree):
    """tree: (tag, [(ns, name, type, value)], [children]). ns is 'android' or None."""
    attr_names = []
    def collect(node):
        tag, attrs, kids = node
        for ns, name, _, _ in attrs:
            if ns == "android" and name not in attr_names:
                attr_names.append(name)
        for k in kids:
            collect(k)
    collect(tree)
    strings = list(attr_names)  # resource-mapped attribute names first
    def sid(s):
        if s not in strings:
            strings.append(s)
        return strings.index(s)
    for s in ("android", ANDROID_NS):
        sid(s)
    body = b""
    # namespace start
    body += struct.pack("<HHIIIII", 0x0100, 16, 24, 1, 0xFFFFFFFF, sid("android"), sid(ANDROID_NS))
    def emit(node, line=[2]):
        nonlocal body
        tag, attrs, kids = node
        packed = b""
        # attributes must be sorted by resource id (android attrs), plain ones last
        def key(a):
            return (0, ATTR[a[1]]) if a[0] == "android" else (1, a[1])
        for ns, name, typ, value in sorted(attrs, key=key):
            ns_ref = sid(ANDROID_NS) if ns == "android" else 0xFFFFFFFF
            name_ref = attr_names.index(name) if ns == "android" else sid(name)
            if typ == T_STRING:
                raw = data = sid(value)
            else:
                raw = 0xFFFFFFFF
                data = value
            packed += struct.pack("<IIIHBBI", ns_ref, name_ref, raw, 8, 0, typ, data & 0xFFFFFFFF)
        start = struct.pack("<IIHHHHHH", 0xFFFFFFFF, sid(tag), 20, 20, len(attrs), 0, 0, 0)
        chunk_body = struct.pack("<II", line[0], 0xFFFFFFFF) + start + packed
        body += struct.pack("<HHI", 0x0102, 16, 8 + len(chunk_body)) + chunk_body
        line[0] += 1
        for k in kids:
            emit(k)
        end_body = struct.pack("<IIII", line[0], 0xFFFFFFFF, 0xFFFFFFFF, sid(tag))
        body += struct.pack("<HHI", 0x0103, 16, 8 + len(end_body)) + end_body
        line[0] += 1
    emit(tree)
    body += struct.pack("<HHIIIII", 0x0101, 16, 24, 99, 0xFFFFFFFF, sid("android"), sid(ANDROID_NS))
    pool = string_pool(strings)
    resmap = struct.pack("<HHI", 0x0180, 8, 8 + 4 * len(attr_names)) + b"".join(struct.pack("<I", ATTR[n]) for n in attr_names)
    payload = pool + resmap + body
    return struct.pack("<HHI", 0x0003, 8, 8 + len(payload)) + payload


def manifest():
    A = "android"
    activity = ("activity", [
        (A, "name", T_STRING, "android.app.NativeActivity"),
        (A, "label", T_STRING, LABEL),
        (A, "exported", T_BOOL, 0xFFFFFFFF),
        (A, "screenOrientation", T_INT_DEC, 1),           # portrait
        (A, "configChanges", 0x11, 0x0FB0),               # keyboard|keyboardHidden|orientation|screenLayout|uiMode|screenSize|smallestScreenSize
    ], [
        ("meta-data", [(A, "name", T_STRING, "android.app.lib_name"), (A, "value", T_STRING, LIB)], []),
        ("intent-filter", [], [
            ("action", [(A, "name", T_STRING, "android.intent.action.MAIN")], []),
            ("category", [(A, "name", T_STRING, "android.intent.category.LAUNCHER")], []),
        ]),
    ])
    application = ("application", [
        (A, "label", T_STRING, LABEL),
        (A, "icon", T_REF, ICON_ID),
        (A, "hasCode", T_BOOL, 0),
        (A, "extractNativeLibs", T_BOOL, 0xFFFFFFFF),
    ], [activity])
    return axml(("manifest", [
        (None, "package", T_STRING, PACKAGE),
        (A, "versionCode", T_INT_DEC, 4),
        (A, "versionName", T_STRING, "1.3"),
    ], [
        ("uses-sdk", [(A, "minSdkVersion", T_INT_DEC, 26), (A, "targetSdkVersion", T_INT_DEC, 33)], []),
        ("uses-feature", [(A, "name", T_STRING, "android.hardware.touchscreen")], []),
        application,
    ]))


# ----------------------------------------------------------------- resources.arsc
def resources():
    values = string_pool(["res/drawable/icon.png"])
    type_strings = string_pool(["drawable"])
    key_strings = string_pool(["icon"])
    name = PACKAGE.encode("utf-16-le").ljust(256, b"\x00")
    pkg_header = 288
    type_strings_off = pkg_header
    key_strings_off = pkg_header + len(type_strings)
    spec = struct.pack("<HHIBBHI", 0x0202, 16, 16 + 4, 1, 0, 0, 1) + struct.pack("<I", 0)
    config = struct.pack("<I", 64) + b"\x00" * 60
    entries_start = 20 + len(config) + 4
    entry = struct.pack("<HHI", 8, 0, 0) + struct.pack("<HBBI", 8, 0, T_STRING, 0)
    type_chunk_body = struct.pack("<BBHII", 1, 0, 0, 1, entries_start) + config + struct.pack("<I", 0) + entry
    type_chunk = struct.pack("<HHI", 0x0201, 20 + len(config), 8 + len(type_chunk_body)) + type_chunk_body
    pkg_body = struct.pack("<I", 0x7F) + name + struct.pack("<IIIII", type_strings_off, 1, key_strings_off, 1, 0)
    pkg_payload = type_strings + key_strings + spec + type_chunk
    pkg = struct.pack("<HHI", 0x0200, pkg_header, 8 + len(pkg_body) + len(pkg_payload)) + pkg_body + pkg_payload
    assert len(struct.pack("<HHI", 0, 0, 0) + pkg_body) == pkg_header
    table_payload = values + pkg
    return struct.pack("<HHII", 0x0002, 12, 12 + len(table_payload), 1) + table_payload


# ----------------------------------------------------------------- zip writer
def build_zip(entries):
    """entries: list of (name, data, stored, align). Returns zip bytes."""
    out, central = bytearray(), bytearray()
    for name, data, stored, align in entries:
        nameb = name.encode()
        crc = zlib.crc32(data) & 0xFFFFFFFF
        if stored:
            comp, method = data, 0
        else:
            c = zlib.compressobj(9, zlib.DEFLATED, -15)
            comp, method = c.compress(data) + c.flush(), 8
        offset = len(out)
        extra = b""
        if stored and align:
            data_start = offset + 30 + len(nameb)
            pad = (-data_start) % align
            extra = b"\x00" * pad
        out += struct.pack("<IHHHHHIIIHH", 0x04034B50, 20, 0x0800, method, 0, 0x21, crc, len(comp), len(data), len(nameb), len(extra))
        out += nameb + extra + comp
        central += struct.pack("<IHHHHHHIIIHHHHHII", 0x02014B50, 20, 20, 0x0800, method, 0, 0x21, crc, len(comp), len(data),
                               len(nameb), 0, 0, 0, 0, 0, offset) + nameb
    cd_offset = len(out)
    eocd = struct.pack("<IHHHHIIH", 0x06054B50, 0, 0, len(entries), len(entries), len(central), cd_offset, 0)
    return bytes(out), bytes(central), eocd


# ----------------------------------------------------------------- v2 signing
def lp(b):
    return struct.pack("<I", len(b)) + b


def chunk_digest(parts):
    digests = []
    for part in parts:
        for i in range(0, len(part), 1 << 20):
            c = part[i:i + (1 << 20)]
            digests.append(hashlib.sha256(b"\xa5" + struct.pack("<I", len(c)) + c).digest())
    return hashlib.sha256(b"\x5a" + struct.pack("<I", len(digests)) + b"".join(digests)).digest()


def key_and_cert(path):
    if path and os.path.exists(path):
        pem = open(path, "rb").read()
        key = serialization.load_pem_private_key(pem, None)
        cert = x509.load_pem_x509_certificate(pem)
        return key, cert
    key = rsa.generate_private_key(public_exponent=65537, key_size=2048)
    name = x509.Name([x509.NameAttribute(NameOID.COMMON_NAME, "narti_live FM-PLAITS")])
    now = datetime.datetime(2026, 1, 1)
    cert = (x509.CertificateBuilder().subject_name(name).issuer_name(name).public_key(key.public_key())
            .serial_number(x509.random_serial_number()).not_valid_before(now)
            .not_valid_after(now + datetime.timedelta(days=365 * 30)).sign(key, hashes.SHA256()))
    if path:
        with open(path, "wb") as f:
            f.write(key.private_bytes(serialization.Encoding.PEM, serialization.PrivateFormat.PKCS8,
                                      serialization.NoEncryption()))
            f.write(cert.public_bytes(serialization.Encoding.PEM))
    return key, cert


def sign_v2(entries_bytes, central, eocd, key, cert):
    algo = 0x0103  # RSASSA-PKCS1-v1_5 with SHA2-256
    digest = chunk_digest([entries_bytes, central, eocd])
    cert_der = cert.public_bytes(serialization.Encoding.DER)
    signed_data = lp(lp(struct.pack("<I", algo) + lp(digest))) + lp(lp(cert_der)) + lp(b"")
    signature = key.sign(signed_data, padding.PKCS1v15(), hashes.SHA256())
    pub = key.public_key().public_bytes(serialization.Encoding.DER, serialization.PublicFormat.SubjectPublicKeyInfo)
    signer = lp(signed_data) + lp(lp(struct.pack("<I", algo) + lp(signature))) + lp(pub)
    value = lp(lp(signer))
    pair = struct.pack("<Q", 4 + len(value)) + struct.pack("<I", 0x7109871A) + value
    size = len(pair) + 8 + 16
    block = struct.pack("<Q", size) + pair + struct.pack("<Q", size) + b"APK Sig Block 42"
    new_eocd = eocd[:16] + struct.pack("<I", len(entries_bytes) + len(block)) + eocd[20:]
    return entries_bytes + block + central + new_eocd


def main():
    lib, icon, out = sys.argv[1:4]
    keyfile = sys.argv[4] if len(sys.argv) > 4 else None
    entries = [
        ("AndroidManifest.xml", manifest(), False, 0),
        ("resources.arsc", resources(), True, 4),
        ("res/drawable/icon.png", open(icon, "rb").read(), True, 4),
    ]
    # `lib` is either one arm64 library or a directory with one sub-folder per ABI.
    if os.path.isdir(lib):
        for abi in ("arm64-v8a", "x86_64", "armeabi-v7a"):
            path = os.path.join(lib, abi, "lib%s.so" % LIB)
            if os.path.exists(path):
                entries.append(("lib/%s/lib%s.so" % (abi, LIB), open(path, "rb").read(), False, 0))
    else:
        entries.append(("lib/arm64-v8a/lib%s.so" % LIB, open(lib, "rb").read(), False, 0))
    body, central, eocd = build_zip(entries)
    key, cert = key_and_cert(keyfile)
    apk = sign_v2(body, central, eocd, key, cert)
    with open(out, "wb") as f:
        f.write(apk)
    print("APK", out, len(apk), "bytes; cert sha256", hashlib.sha256(cert.public_bytes(serialization.Encoding.DER)).hexdigest()[:16])


if __name__ == "__main__":
    main()
