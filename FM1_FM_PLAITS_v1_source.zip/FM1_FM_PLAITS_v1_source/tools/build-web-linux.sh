#!/usr/bin/env bash
# SPDX-License-Identifier: GPL-3.0-only WITH GPL-3.0-linking-exception
# Linux/macOS equivalent of tools/Build-Web.ps1 -LocalPreview.
# Builds the browser simulator (build/web/simulator.wasm) and the preview
# page (build/preview/index.html) from the same C sources as the firmware.
# Usage: FM1_WASI_SDK=/path/to/wasi-sdk-27.0 tools/build-web-linux.sh
set -euo pipefail
root="$(cd "$(dirname "$0")/.." && pwd)"
sdk="${FM1_WASI_SDK:?Set FM1_WASI_SDK to an extracted WASI SDK 27 directory}"
out="$root/build/web"; mkdir -p "$out" "$root/build/preview"
sources=$(cd "$root" && find app web third_party/synth -name '*.c' ! -path 'app/board/*' | LC_ALL=C sort)
inc=""; for d in web/engine web/synth third_party/synth sdk/include app/synth app; do inc="$inc -I$root/$d"; done
args=(--sysroot="$sdk/share/wasi-sysroot" -std=c11 -O2 -fwrapv -fno-fast-math -ffp-contract=off
      -DFM1_HOST_TEST -DFM1_OPEN_WEB -Wall -Wextra -Werror -Wno-unused-function -Wno-array-parameter
      -mexec-model=reactor)
src=(); for s in $sources; do src+=("$root/$s"); done
echo "Compile the browser application"
"$sdk/bin/clang" "${args[@]}" $inc "${src[@]}" -Wl,--strip-all -Wl,-z,stack-size=131072 \
    -Wl,--initial-memory=4194304 -Wl,--max-memory=33554432 -o "$out/simulator.wasm"
node "$root/tools/pack-preview.mjs" "$root" "$out/simulator.wasm" "$root/build/preview/index.html"
echo "Preview: build/preview/index.html"
