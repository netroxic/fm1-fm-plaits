# SPDX-License-Identifier: GPL-3.0-only WITH GPL-3.0-linking-exception
# Generative FM-PLAITS cloud build (GitHub Actions, Windows): runs
# build.bat --package and, only if the firmware does not fit the FM1 flash
# layout, retries with smaller code (app/fpl_size.h levels 1..3).
# Every result is also written as a GitHub annotation, which is public and
# readable without signing in. Requires FM1_PI32_TOOLCHAIN and FM1_SOURCE_URL.
$ErrorActionPreference = 'Stop'
$root = if ($env:FM1_ROOT) { $env:FM1_ROOT } else { Split-Path -Parent $PSScriptRoot }
Set-Location $root
$temp = if ($env:RUNNER_TEMP) { $env:RUNNER_TEMP } else { [IO.Path]::GetTempPath() }
$log = Join-Path $temp 'build-inner.log'
$report = Join-Path $root 'build/ci-report.txt'
$limit = 453921   # sdk/Package.cs: largest application image that fits the layout

function Annotate([string]$level, [string]$title, [string]$text) {
    $t = $text.Replace('%', '%25').Replace("`r", '').Replace("`n", '%0A')
    Write-Host "::${level} title=${title}::$t"
}
function Sha([string]$path) { (Get-FileHash -LiteralPath $path -Algorithm SHA256).Hash.ToLowerInvariant() }

$buildPs1 = Join-Path $root 'sdk/Build.ps1'
$manifestPath = Join-Path $root 'sdk/manifest.json'
$sizeHeader = Join-Path $root 'app/fpl_size.h'
$pristine = [IO.File]::ReadAllText($buildPs1)
$optNeedle = "'-D__GCC_PI32V2__','-O2')"
if (!$pristine.Contains($optNeedle)) { Annotate 'warning' 'Size levels' 'Optimisation flag not found in sdk/Build.ps1; levels 1-2 change nothing.' }

function Set-Level([int]$n, [string]$opt) {
    $h = [IO.File]::ReadAllText($sizeHeader)
    $h = [regex]::Replace($h, '(?m)^#define FPL_SIZE_LEVEL \d+', "#define FPL_SIZE_LEVEL $n")
    [IO.File]::WriteAllText($sizeHeader, $h)
    [IO.File]::WriteAllText($buildPs1, $pristine.Replace($optNeedle, "'-D__GCC_PI32V2__','$opt')"))
    # The SDK manifest records Build.ps1's hash; keep it consistent with the change.
    $m = Get-Content -LiteralPath $manifestPath -Raw | ConvertFrom-Json
    $m.files.'sdk/Build.ps1' = Sha $buildPs1
    [IO.File]::WriteAllText($manifestPath, ($m | ConvertTo-Json -Depth 32))
    return $opt
}
function Invoke-Build {
    if ($env:FPL_CI_FAKE) { & $env:FPL_CI_FAKE $log; return $LASTEXITCODE }
    # build.bat runs Windows PowerShell 5.1: give it its own module path.
    $env:FPL_CI_INNER = '1'
    cmd /d /c "set PSModulePath=&& call build.bat --package > $log 2>&1"
    return $LASTEXITCODE
}
function Largest-Symbols {
    $elf = Join-Path $root 'build/dx7/sdk.elf'
    $nm = Join-Path $env:FM1_PI32_TOOLCHAIN 'bin/llvm-nm.exe'
    if (!(Test-Path $elf) -or !(Test-Path $nm)) { return 'no ELF to inspect' }
    $rows = & $nm --print-size --size-sort $elf 2>$null | Select-Object -Last 45
    $global:LASTEXITCODE = 0
    $out = foreach ($r in $rows) {
        $p = -split $r
        if ($p.Count -ge 4) { '{0,7} {1}' -f [Convert]::ToInt64($p[1], 16), $p[3] }
    }
    [array]::Reverse($out)
    return ($out -join "`n")
}

function Image-Breakdown {
    # Sizes of everything that is stored in the flash image, from the linker map.
    $mapFile = Join-Path $root 'build/dx7/sdk.map'
    if (!(Test-Path $mapFile)) { return 'no linker map' }
    $want = @('.text', '.data', '.ram0_data', '.cache_ram_data')
    $cur = $null; $pending = $null
    $items = New-Object System.Collections.Generic.List[object]
    foreach ($line in [IO.File]::ReadLines($mapFile)) {
        if ($line -match '^(\.[^\s]+)\s+0x[0-9a-fA-F]+\s+0x[0-9a-fA-F]+') { $cur = $Matches[1]; $pending = $null; continue }
        if ($line -match '^(\.[^\s]+)\s*$') { $cur = $Matches[1]; $pending = $null; continue }
        if ($line -match '^ (\.[^\s]+|COMMON)\s+0x([0-9a-fA-F]+)\s+0x([0-9a-fA-F]+)\s+(\S.*)$') {
            $n = $Matches[1]; $z = [Convert]::ToInt64($Matches[3], 16); $f = $Matches[4]
        } elseif ($line -match '^ (\.[^\s]+|COMMON)\s*$') { $pending = $Matches[1]; continue }
        elseif ($pending -and $line -match '^\s+0x([0-9a-fA-F]+)\s+0x([0-9a-fA-F]+)\s+(\S.*)$') {
            $n = $pending; $z = [Convert]::ToInt64($Matches[2], 16); $f = $Matches[3]; $pending = $null
        } else { continue }
        if ($want -contains $cur -and $z -gt 0) { $items.Add([pscustomobject]@{out=$cur; name=$n; size=$z; file=($f -replace '^.*[\\/]', '')}) }
    }
    if ($items.Count -eq 0) {
        return "map not parsed; first lines:`n" + ((Get-Content $mapFile -TotalCount 400 | Where-Object { $_ -match '0x' } | Select-Object -First 25) -join "`n")
    }
    $lines = @('by output section:')
    $lines += $items | Group-Object out | ForEach-Object { '{0,8} {1}' -f ($_.Group | Measure-Object size -Sum).Sum, $_.Name }
    $lines += 'by input file (top 14):'
    $lines += $items | Group-Object { $_.file -replace '\(.*$', '' } | ForEach-Object { [pscustomobject]@{n=$_.Name; s=($_.Group | Measure-Object size -Sum).Sum} } |
        Sort-Object s -Descending | Select-Object -First 14 | ForEach-Object { '{0,8} {1}' -f $_.s, $_.n }
    $lines += 'largest input sections (top 34):'
    $lines += $items | Sort-Object size -Descending | Select-Object -First 34 | ForEach-Object { '{0,8} {1} {2} [{3}]' -f $_.size, $_.out, $_.name, $_.file }
    return ($lines -join "`n")
}
$sizes = [ordered]@{}
$done = $false
# Measured (build #9): even the unmodified FM1 Open V14 leaves only 185 bytes
# with JieLi's current compiler, so FM-PLAITS needs level 5 (fpl_size.h).
$configs = @(@(5, '-O2'), @(5, '-Oz'))
foreach ($c in $configs) {
    $level = $c[0]; $opt = Set-Level $c[0] $c[1]
    Write-Host "==== Build level $level ($opt) ===="
    $rc = Invoke-Build
    $text = if (Test-Path $log) { Get-Content $log -Raw } else { '' }
    Write-Host $text
    $size = [regex]::Match($text, 'FM1: (\d+) bytes app image')
    $sizes["level $level ($opt)"] = if ($size.Success) { [int]$size.Groups[1].Value } else { $null }
    if ($rc -eq 0) { $done = $true; break }
    if ($text -notmatch 'does not fit the FM1 layout') {
        $tail = ((Get-Content $log | Where-Object { $_.Trim() } | Select-Object -Last 45) -join "`n")
        Annotate 'error' "Build failed at size level $level ($opt)" $tail
        exit $rc
    }
    $over = if ($size.Success) { [int]$size.Groups[1].Value - $limit } else { '?' }
    Annotate 'warning' "Level $level ($opt) too big by $over bytes" (Image-Breakdown)
}
$summary = ($sizes.GetEnumerator() | ForEach-Object { "$($_.Key): $($_.Value) bytes" }) -join "`n"
New-Item -ItemType Directory -Force -Path (Split-Path $report) | Out-Null
if ($done) {
    $lvl = $level
    $note = if ($lvl -ge 5) { 'FM-PLAITS only: original editor pages and DX7 factory voices removed (optimisation ' + $opt + ').' }
            elseif ($lvl -ge 4) { 'DX7 factory bank reduced to one program (FM-PLAITS does not use it).' }
            elseif ($lvl -ge 3) { 'DX7 factory bank reduced to its first 32 programs.' } else { 'All features kept.' }
    [IO.File]::WriteAllText($report, "Generative FM-PLAITS build: OK at size level $lvl. $note`nLimit $limit bytes.`n$summary`n")
    Annotate 'notice' "Build OK at size level $lvl" "$note`nLimit $limit bytes`n$summary"
    exit 0
}
Annotate 'error' 'Still too big at every size level' "Limit $limit bytes`n$summary`n`n$(Largest-Symbols)"
exit 1
