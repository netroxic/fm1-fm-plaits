// SPDX-License-Identifier: GPL-3.0-only WITH GPL-3.0-linking-exception
// Node port of the local-preview packaging step in tools/Build-Web.ps1.
// Usage: node tools/pack-preview.mjs <root> <simulator.wasm> <output.html>
import { readFileSync, writeFileSync } from 'node:fs';
import { createHash } from 'node:crypto';
import { join } from 'node:path';

const [root, wasmPath, output] = process.argv.slice(2);
const read = (p) => readFileSync(join(root, p), 'utf8');
const wasm = readFileSync(wasmPath);
const sha = (b) => createHash('sha256').update(b).digest('hex');
const version = /#define FM1_RELEASE_VERSION "(V\d+)"/.exec(read('app/version.h'))[1];
const simulation = {
  schema: 1, release_version: version, sha256: sha(wasm), source_sha256: sha(wasm),
  sample_bank: 'synthesized-demo', data: wasm.toString('base64'),
};
const html = (s) => s.replace(/[&<>"']/g, (c) => ({ '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;', "'": '&#39;' }[c]));
let web = read('sdk/Update.html.in');
web = web.replace(/<a\b[^>]*href="\/\*FM1_SOURCE_URL\*\/"[^>]*>(.*?)<\/a>/g, '<span>$1 (local preview)</span>');
let notices = ['APP: GPLv3 with the FM1 SDK linking exception; no warranty. SDK and firmware resources have separate redistribution terms in THIRD_PARTY.md. Source: local preview'];
for (const f of ['THIRD_PARTY.md', 'LICENSE.md']) notices.push(`\n===== ${f} =====\n` + read(f));
const replacements = {
  '/*FM1_SOURCE_URL*/': '',
  '/*FM1_PAYLOAD*/': 'const FM1_PACKAGE = null;',
  '/*FM1_SIMULATOR*/': 'const FM1_SIMULATOR = ' + JSON.stringify(simulation) + ';',
  '/*FM1_I18N*/': read('sdk/I18n.js'),
  '/*FM1_SCRIPT*/': read('sdk/WebUpdate.js'),
  '/*FM1_SIM_SCRIPT*/': read('sdk/Simulator.js'),
  '/*FM1_SAMPLE_SCRIPT*/': read('sdk/Samples.js'),
  '/*FM1_NOTICES*/': html(notices.join('\n')),
};
for (const [k, v] of Object.entries(replacements)) web = web.split(k).join(v);
if (/\/\*FM1_[A-Z_]+\*\//.test(web)) throw new Error('Unexpanded HTML placeholder');
writeFileSync(output, web);
