/* SPDX-License-Identifier: GPL-3.0-only WITH GPL-3.0-linking-exception
 * Generative FM-PLAITS (FM1): ping-pong delay + "black hole" reverb — @narti_live.
 * Same design as the Android app, sized for the FM1's SRAM: both effects run
 * at half rate (22.05 kHz) on 16-bit delay memory (~100 KiB in total), with
 * the dry voice kept at full bandwidth. Audio context: SRAM code, no libc. */
#include "fm1.h"
#include "fpl_audio.h"

#define AC FM1_AUDIO_CODE
#define AI static inline __attribute__((always_inline))
#define AH static FM1_AUDIO_CODE /* one shared SRAM copy */
#define HALF_RATE 22050.0f
enum { LINES = 8, LINE = 2048, DIFF = 4, DIFF_LEN = 512, DLY = 16384, N = FM1_BLOCK_FRAMES };
#define STORE 8192.0f
#define LOAD (1.0f / 8192.0f)

struct fpl_fx_shared fpl_fx = {0.3f, 0.7f, 0.6f, 0.35f, 0.2f, 0.45f, 0.75f, 120U};
static int16_t line[LINES][LINE], diff[DIFF][DIFF_LEN], dly[2][DLY];
static float line_lp[LINES], mod_phase[LINES], dly_lp[2];
static unsigned line_pos, diff_pos, dly_pos, toggle;
static float dly_time = -1.0f, size_s = -1.0f, acc_in, wet_l, wet_r, prev_l, prev_r;

static FM1_AUDIO_DATA const float line_ms[LINES] = {32.43f, 33.71f, 31.07f, 29.63f, 26.61f, 28.27f, 24.77f, 23.29f};
static FM1_AUDIO_DATA const float diff_ms[DIFF] = {2.96f, 2.23f, 7.89f, 5.77f};
static FM1_AUDIO_DATA const float mod_rate[LINES] = {0.31f, 0.37f, 0.43f, 0.29f, 0.53f, 0.41f, 0.23f, 0.47f};

AI float clampf(float x, float lo, float hi) { return x < lo ? lo : x > hi ? hi : x; }
AH float soft(float x)
{
    x = clampf(x, -3.0f, 3.0f);
    return x * (27.0f + x * x) / (27.0f + 9.0f * x * x);
}
AH float fexp2(float x)
{
    x = clampf(x, -30.0f, 30.0f);
    int i = (int)x;
    if ((float)i > x) --i;
    float f = x - (float)i;
    union { float f; int32_t i; } u;
    u.f = 1.0f + f * (0.6951786f + f * (0.2262058f + f * 0.0782133f));
    u.i += (int32_t)((uint32_t)i << 23);
    return u.f;
}
AH int16_t pack(float v)
{
    v *= STORE;
    v = clampf(v, -32767.0f, 32767.0f);
    return (int16_t)(v < 0.0f ? v - 0.5f : v + 0.5f);
}
AH float tap(const int16_t *b, unsigned mask, unsigned pos, float delay)
{
    float rp = (float)pos - delay;
    if (rp < 0.0f) rp += (float)(mask + 1U);
    unsigned i = (unsigned)rp;
    float f = rp - (float)i;
    float a = (float)b[i & mask], c = (float)b[(i + 1U) & mask];
    return (a + (c - a) * f) * LOAD;
}

AC void fpl_fx_run(const float *x, float *out_l, float *out_r)
{
    float dmix = clampf(fpl_fx.del_mix, 0.0f, 1.0f), fb = clampf(fpl_fx.del_feedback, 0.0f, 0.95f);
    unsigned tempo = fpl_fx.tempo >= 20U && fpl_fx.tempo <= 400U ? fpl_fx.tempo : 120U;
    float dtime = clampf(fpl_fx.del_quarters * 60.0f / (float)tempo * HALF_RATE, 16.0f, (float)(DLY - 8));
    if (dly_time < 0.0f) dly_time = dtime;
    float rmix = clampf(fpl_fx.rev_mix, 0.0f, 1.0f), size = clampf(fpl_fx.rev_size, 0.0f, 1.0f);
    float decay = clampf(fpl_fx.rev_decay, 0.0f, 1.0f), tone = clampf(fpl_fx.rev_tone, 0.0f, 1.0f);
    if (size_s < 0.0f) size_s = size;
    unsigned freeze = decay >= 0.99f;
    float t60 = 0.6f * fexp2(decay * 6.5f), damp = 0.06f + tone * tone * 0.9f;
    float ms = HALF_RATE * 0.001f, gains[LINES];
    for (unsigned i = 0; i < LINES; ++i)
        gains[i] = freeze ? 1.0f : fexp2(-9.9658f * line_ms[i] * ms * (0.35f + size_s * 2.25f) / (t60 * HALF_RATE));
    for (unsigned n = 0; n < N; ++n) {
        acc_in += x[n];
        if (n & 1U) {
            /* ---- one half-rate frame ---- */
            float d = acc_in * 0.5f, l = d, r = d;
            acc_in = 0.0f;
            float anti = (toggle++ & 1U) ? 1e-9f : -1e-9f;
            dly_time += (dtime - dly_time) * 0.0008f;
            if (dmix > 0.0f || fb > 0.0f) {
                float dl = tap(dly[0], DLY - 1U, dly_pos, dly_time), dr = tap(dly[1], DLY - 1U, dly_pos, dly_time);
                dly_lp[0] += (dl - dly_lp[0]) * 0.55f;
                dly_lp[1] += (dr - dly_lp[1]) * 0.55f;
                dly[0][dly_pos] = pack(soft(d + dly_lp[1] * fb) + anti);
                dly[1][dly_pos] = pack(soft(dly_lp[0] * fb) + anti);
                dly_pos = (dly_pos + 1U) & (DLY - 1U);
                l += dl * dmix;
                r += dr * dmix;
            }
            if (rmix > 0.0f || freeze) {
                size_s += (size - size_s) * 0.0001f;
                float scale = 0.35f + size_s * 2.25f;
                float in = freeze ? 0.0f : (l + r) * 0.25f;
                for (unsigned k = 0; k < DIFF; ++k) {
                    float delayed = tap(diff[k], DIFF_LEN - 1U, diff_pos, diff_ms[k] * ms * (0.6f + size_s));
                    float w = in + 0.65f * delayed;
                    diff[k][diff_pos] = pack(w);
                    in = delayed - 0.65f * w;
                }
                diff_pos = (diff_pos + 1U) & (DIFF_LEN - 1U);
                float v[LINES];
                for (unsigned i = 0; i < LINES; ++i) {
                    mod_phase[i] += mod_rate[i] * (1.0f / HALF_RATE);
                    if (mod_phase[i] >= 1.0f) mod_phase[i] -= 1.0f;
                    float tri = mod_phase[i] < 0.5f ? mod_phase[i] * 4.0f - 1.0f : 3.0f - mod_phase[i] * 4.0f;
                    float len = clampf(line_ms[i] * ms * scale + tri * 3.0f * (0.5f + size_s), 8.0f, (float)(LINE - 8));
                    float s = tap(line[i], LINE - 1U, line_pos, len);
                    line_lp[i] += (s - line_lp[i]) * (freeze ? 1.0f : damp);
                    v[i] = line_lp[i] * gains[i];
                }
                for (unsigned h = 1; h < LINES; h <<= 1)
                    for (unsigned i = 0; i < LINES; i += h << 1)
                        for (unsigned j = i; j < i + h; ++j) { float a = v[j], b = v[j + h]; v[j] = a + b; v[j + h] = a - b; }
                float wl = 0.0f, wr = 0.0f;
                for (unsigned i = 0; i < LINES; ++i) {
                    float y = v[i] * 0.35355339f;
                    line[i][line_pos] = pack(y + ((i & 1U) ? -in : in) + anti);
                    if (i & 1U) wr += y; else wl += y;
                }
                line_pos = (line_pos + 1U) & (LINE - 1U);
                l = l * (1.0f - rmix * 0.45f) + wl * rmix * 0.9f;
                r = r * (1.0f - rmix * 0.45f) + wr * rmix * 0.9f;
            }
            prev_l = wet_l; prev_r = wet_r;
            wet_l = l - d; wet_r = r - d;          /* effect part only; dry stays full-rate */
        }
        /* Linear interpolation of the half-rate effect signal. */
        float t = (n & 1U) ? 1.0f : 0.5f;
        out_l[n] = x[n] + prev_l + (wet_l - prev_l) * t;
        out_r[n] = x[n] + prev_r + (wet_r - prev_r) * t;
    }
}
