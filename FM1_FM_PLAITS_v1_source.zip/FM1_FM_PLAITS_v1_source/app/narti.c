/* SPDX-License-Identifier: GPL-3.0-only WITH GPL-3.0-linking-exception
 * Generative FM-PLAITS — generative melody sequencer and sound control.
 * By @narti_live. Generator inspired by the Sting Max for Live device:
 * every step gets a rank and random thresholds once, so DENSITY, SLIDE and
 * the scale can be turned live without re-rolling the melody.
 * Integer-only, allocation-free, control task only. */
#include "instrument.h"
#include "narti.h"
#include "fpl_voice.h"
#include "fpl_audio.h"
#include <string.h>

struct narti_state narti;
extern volatile unsigned fpl_midi_out;
#define COLD __attribute__((cold, minsize))

static const uint8_t scales[NARTI_SCALES][13] = {
    {7, 0, 2, 3, 5, 7, 8, 10},  {7, 0, 1, 3, 5, 7, 8, 10}, {7, 0, 2, 3, 5, 7, 9, 10},
    {7, 0, 2, 4, 5, 7, 9, 11},  {5, 0, 3, 5, 7, 10},       {5, 0, 2, 4, 7, 9},
    {6, 0, 2, 4, 6, 8, 10},     {12, 0, 1, 2, 3, 4, 5, 6, 7, 8, 9, 10, 11}};
static const char *const scale_names[NARTI_SCALES] = {"MINOR", "PHRYG", "DORIAN", "MAJOR", "PENTA-", "PENTA+", "WHOLE", "CHROM"};
static const char *const note_names[12] = {"C", "C#", "D", "D#", "E", "F", "F#", "G", "G#", "A", "A#", "B"};
/* Melodic interval wishes, most consonant first; quantized to the scale. */
static const uint8_t intervals[12] = {7, 12, 3, 5, 10, 4, 15, 19, 2, 9, 14, 24};

static uint32_t seed = 0x706c6169U; /* "plai" */
static struct {
    uint8_t rank[NARTI_STEPS], note_r[NARTI_STEPS], oct_r[NARTI_STEPS], acc_r[NARTI_STEPS], sld_r[NARTI_STEPS];
    uint8_t valid;
} history;
static struct { int32_t from, to, elapsed, period; } lfo[3];
static uint32_t lfo_ms;
static unsigned bars_mark, was_playing;

static uint32_t rnd(void) { seed ^= seed << 13; seed ^= seed >> 17; seed ^= seed << 5; return seed; }
static unsigned rnd_below(unsigned n) { return n ? (rnd() >> 8) % n : 0; }
static int clampi(int v, int lo, int hi) { return v < lo ? lo : v > hi ? hi : v; }
static void stir(void)
{
    struct fm1_render_stats s;
    groove_audio_stats(&s);
    seed ^= fm1_millis() * 2654435761U ^ s.render_ticks ^ (s.peak_ticks << 7);
    if (!seed) seed = 0x706c6169U;
    (void)rnd();
}
const char *narti_scale_name(unsigned s) { return s < NARTI_SCALES ? scale_names[s] : ""; }
const char *narti_note_name(unsigned pc) { return note_names[pc % 12]; }

/* ------------------------------------------------------------ sound */
static void sound_push(void)
{
    const uint8_t *v = narti.mod_on ? narti.live : &narti.harmonics;
    fpl.harmonics = (float)v[0] * 0.01f;
    fpl.timbre = (float)v[1] * 0.01f;
    fpl.morph = (float)v[2] * 0.01f;
    fpl.transpose = (float)(narti.freq * 12); /* FREQ in octaves */
    fpl.lpg = (float)narti.lpg * 0.02f;
    fpl.engine = narti.engine;
}
void narti_sound_edit(unsigned p, int delta)
{
    if (!delta) return;
    if (p == NS_FREQ) narti.freq = (int8_t)clampi((int)narti.freq + delta, -2, 2);
    else if (p <= NS_MORPH) {
        uint8_t *v = &narti.harmonics + p;
        *v = (uint8_t)clampi((int)*v + delta, 0, 100);
        if (!narti.mod_on) narti.live[p] = *v;
    }
    sound_push();
}
void narti_engine_edit(int delta)
{
    narti.engine = (uint8_t)clampi((int)narti.engine + delta, 0, FPL_ENGINES - 1);
    sound_push();
}
void narti_lpg_edit(int delta)
{
    narti.lpg = (int8_t)clampi((int)narti.lpg + delta, -50, 50);
    sound_push();
}
static void flash(void) { narti.flash = 1; narti.flash_until = fm1_millis() + 220U; }
void narti_random_sound(void)
{
    stir();
    narti.harmonics = (uint8_t)rnd_below(101);
    narti.timbre = (uint8_t)rnd_below(101);
    narti.morph = (uint8_t)rnd_below(101);
    narti.lpg = (int8_t)((int)rnd_below(81) - 30);
    memcpy(narti.live, &narti.harmonics, 3);
    memset(lfo, 0, sizeof lfo);
    sound_push();
    flash();
}
void narti_mod_toggle(void)
{
    narti.mod_on ^= 1U;
    memset(lfo, 0, sizeof lfo);
    memcpy(narti.live, &narti.harmonics, 3);
    sound_push();
}
void narti_mod_edit(unsigned p, int delta)
{
    if (p == NM_SPEED) narti.mod_speed = (uint8_t)clampi((int)narti.mod_speed + delta, 0, 100);
    else narti.mod_depth = (uint8_t)clampi((int)narti.mod_depth + delta, 0, 100);
}
static void mod_poll(uint32_t now)
{
    uint32_t dt = now - lfo_ms;
    if (dt < 15U) return;
    lfo_ms = now;
    if (dt > 200U) dt = 200U;
    if (!narti.mod_on) return;
    /* Exponential: 100 ms glides at 100 down to 90 s at 0 (10x slower than v1). */
    float octs = (float)(100 - narti.mod_speed) * 0.098137f;
    int whole = (int)octs;
    float frac = octs - (float)whole;
    unsigned base = (unsigned)(100.0f * (float)(1U << whole) * (1.0f + frac * (0.6951786f + frac * (0.2262058f + frac * 0.0782133f))));
    static const uint8_t rate[3] = {16, 23, 13};
    for (unsigned t = 0; t < 3; ++t) {
        if (!lfo[t].period || lfo[t].elapsed >= lfo[t].period) {
            lfo[t].from = lfo[t].period ? lfo[t].to : 0;
            lfo[t].to = (int16_t)((int)rnd_below(2049) - 1024);
            lfo[t].elapsed = 0;
            unsigned p = base * rate[t] / 16U * (80U + rnd_below(41)) / 100U;
            lfo[t].period = (int32_t)(p < 40U ? 40U : p > 200000U ? 200000U : p);
        }
        lfo[t].elapsed = lfo[t].elapsed + (int32_t)dt > lfo[t].period ? lfo[t].period : lfo[t].elapsed + (int32_t)dt;
        int x = (int)((int64_t)lfo[t].elapsed * 1024 / lfo[t].period);
        int s = x * x / 1024 * (3072 - 2 * x) / 1024;
        int cur = lfo[t].from + (lfo[t].to - lfo[t].from) * s / 1024;
        int offset = cur * 50 * (int)narti.mod_depth / (1024 * 100);
        narti.live[t] = (uint8_t)clampi((int)(&narti.harmonics)[t] + offset, 0, 100);
    }
    sound_push();
}

/* ------------------------------------------------------------ generator */
static unsigned quantize(unsigned scale, int semitone)
{
    int octave = semitone / 12, pc = semitone - octave * 12, best = 0, distance = 99;
    const uint8_t *s = scales[scale % NARTI_SCALES];
    for (unsigned i = 1; i <= s[0]; ++i) {
        int d = pc - (int)s[i], a = d < 0 ? -d : d;
        if (a < distance || (a == distance && (int)s[i] > best)) { distance = a; best = s[i]; }
        d = pc - (int)s[i] - 12; a = d < 0 ? -d : d;
        if (a < distance) { distance = a; best = s[i] + 12; }
    }
    return (unsigned)(octave * 12 + best);
}
static COLD void render(void)
{
    unsigned length = narti.length ? narti.length : 16, count = (narti.density * length + 8U) / 16U;
    if (count < 1) count = 1;
    if (count > length) count = length;
    memset(narti.on, 0, sizeof narti.on);
    for (unsigned i = 0; i < length; ++i) {
        unsigned better = 0;
        for (unsigned j = 0; j < length; ++j)
            better += narti.rank[j] < narti.rank[i] || (narti.rank[j] == narti.rank[i] && j < i);
        narti.on[i] = better < count;
    }
    for (unsigned i = 0; i < NARTI_STEPS; ++i) {
        narti.acc[i] = narti.sld[i] = 0;
        if (i >= length || !narti.on[i]) { narti.note[i] = 0; continue; }
        unsigned r = narti.note_r[i], semis = 0;
        if (r < 30U + narti.spread * 3U / 5U) {
            unsigned usable = 3U + narti.spread * 9U / 100U;
            semis = intervals[(r * 7U) % (usable > 12U ? 12U : usable)];
        }
        if (narti.oct_r[i] < narti.spread / 5U) semis += 12;
        unsigned pitch = 12U * (narti.octave + 1U) + narti.root + quantize(narti.scale, (int)semis);
        narti.note[i] = (uint8_t)clampi((int)pitch, 0, 120);
        narti.acc[i] = narti.acc_r[i] < narti.accent;
    }
    for (unsigned i = 0; i < length; ++i) {
        unsigned next = (i + 1U) % length;
        narti.sld[i] = narti.on[i] && narti.on[next] && length > 1 && narti.sld_r[i] < narti.slide;
    }
    /* Hand the pattern to the tick-locked audio sequencer (fpl_seq.c). */
    for (unsigned i = 0; i < NARTI_STEPS; ++i) {
        fpl_seq.note[i] = narti.note[i]; fpl_seq.acc[i] = narti.acc[i];
        fpl_seq.sld[i] = narti.sld[i]; fpl_seq.on[i] = narti.on[i];
    }
    fpl_seq.length = (uint8_t)length;
}
static void groove_push(void)
{
    fpl_seq.speed = narti.speed; fpl_seq.triplet = narti.triplet; fpl_seq.chance = narti.chance;
    static const float quarters[6] = {0.25f, 1.0f / 3.0f, 0.5f, 0.75f, 1.0f, 2.0f};
    fpl_fx.rev_mix = (float)narti.rev_mix * 0.01f;
    fpl_fx.rev_size = (float)narti.rev_size * 0.01f;
    fpl_fx.rev_decay = (float)narti.rev_decay * 0.01f;
    fpl_fx.rev_tone = (float)narti.rev_tone * 0.01f;
    fpl_fx.del_mix = (float)narti.del_mix * 0.01f;
    fpl_fx.del_feedback = (float)narti.del_fb * 0.01f;
    fpl_fx.del_quarters = quarters[narti.del_div % 6U];
}
void narti_groove_edit(unsigned p, int delta)
{
    if (!delta) return;
    switch (p) {
    case NQ_SPEED: narti.speed = (uint8_t)clampi((int)narti.speed + delta, 0, 4); break;
    case NQ_TRIPLET: narti.triplet = delta > 0; break;
    case NQ_CHANCE: narti.chance = (uint8_t)clampi((int)narti.chance + delta, 0, 100); break;
    case NQ_REV_MIX: narti.rev_mix = (uint8_t)clampi((int)narti.rev_mix + delta, 0, 100); break;
    case NQ_REV_SIZE: narti.rev_size = (uint8_t)clampi((int)narti.rev_size + delta, 0, 100); break;
    case NQ_REV_DECAY: narti.rev_decay = (uint8_t)clampi((int)narti.rev_decay + delta, 0, 100); break;
    case NQ_REV_TONE: narti.rev_tone = (uint8_t)clampi((int)narti.rev_tone + delta, 0, 100); break;
    case NQ_DEL_MIX: narti.del_mix = (uint8_t)clampi((int)narti.del_mix + delta, 0, 100); break;
    case NQ_DEL_TIME: narti.del_div = (uint8_t)clampi((int)narti.del_div + delta, 0, 5); break;
    case NQ_DEL_FB: narti.del_fb = (uint8_t)clampi((int)narti.del_fb + delta, 0, 95); break;
    default: return;
    }
    groove_push();
}
static void remember(void)
{
    memcpy(history.rank, narti.rank, NARTI_STEPS); memcpy(history.note_r, narti.note_r, NARTI_STEPS);
    memcpy(history.oct_r, narti.oct_r, NARTI_STEPS); memcpy(history.acc_r, narti.acc_r, NARTI_STEPS);
    memcpy(history.sld_r, narti.sld_r, NARTI_STEPS);
    history.valid = 1;
}
static void seeds(void)
{
    for (unsigned i = 0; i < NARTI_STEPS; ++i) {
        unsigned pos = i & 3U, bias = pos == 0 ? 20 : pos == 2 ? 30 : 50;
        unsigned r = bias + rnd_below(150);
        narti.rank[i] = (uint8_t)(r > 255 ? 255 : r);
        narti.note_r[i] = (uint8_t)rnd_below(100);
        narti.oct_r[i] = (uint8_t)rnd_below(100);
        narti.acc_r[i] = (uint8_t)rnd_below(100);
        narti.sld_r[i] = (uint8_t)rnd_below(100);
    }
    if (rnd_below(100) < 75) { narti.rank[0] = 0; narti.note_r[0] = 99; } /* anchor on the root */
}
COLD void narti_generate(void) { stir(); remember(); seeds(); render(); flash(); }
COLD void narti_mutate(unsigned amount)
{
    stir();
    remember();
    for (unsigned n = 0; n < amount; ++n) {
        unsigned i = rnd_below(NARTI_STEPS);
        switch (rnd_below(4)) {
        case 0: narti.rank[i] = (uint8_t)rnd_below(200); break;
        case 1: narti.note_r[i] = (uint8_t)rnd_below(100); break;
        case 2: narti.oct_r[i] = (uint8_t)rnd_below(100); break;
        default: narti.sld_r[i] = (uint8_t)rnd_below(100); break;
        }
    }
    render();
    flash();
}
COLD void narti_undo(void)
{
    if (!history.valid) return;
    uint8_t t[NARTI_STEPS];
#define SWAP(f) memcpy(t, narti.f, NARTI_STEPS); memcpy(narti.f, history.f, NARTI_STEPS); memcpy(history.f, t, NARTI_STEPS)
    SWAP(rank); SWAP(note_r); SWAP(oct_r); SWAP(acc_r); SWAP(sld_r);
#undef SWAP
    render();
    flash();
}
void narti_seq_edit(unsigned p, int delta)
{
    if (!delta) return;
    switch (p) {
    case NG_ROOT: narti.root = (uint8_t)(((int)narti.root + delta % 12 + 12) % 12); break;
    case NG_SCALE: narti.scale = (uint8_t)clampi((int)narti.scale + delta, 0, NARTI_SCALES - 1); break;
    case NG_DENSITY: narti.density = (uint8_t)clampi((int)narti.density + delta, 1, 16); break;
    case NG_LENGTH: narti.length = (uint8_t)clampi((int)narti.length + delta, 1, 16); break;
    case NG_SLIDE: narti.slide = (uint8_t)clampi((int)narti.slide + delta, 0, 100); break;
    case NG_OCTAVE: narti.octave = (uint8_t)clampi((int)narti.octave + delta, 1, 5); break;
    default: return;
    }
    render();
}
void narti_transpose(unsigned key)
{
    narti.root = (uint8_t)((key + 5U) % 12U); /* key 0 is F3 */
    render();
}
void narti_evolve_toggle(void) { narti.evolve ^= 1U; bars_mark = fpl_seq_bars; }

/* ------------------------------------------------------------ MIDI out */
void narti_midi_set(unsigned on)
{
    on = on != 0;
    narti.midi_out = (uint8_t)on;
    fpl_midi_out = on;
    int ch = (int)groove_midi_setting(NARTI_TRACK, 1);
    if (on && ch) groove_settings_midi(NARTI_TRACK, 1, -ch); /* channel 1 */
    int clock = (int)groove_midi_setting(NARTI_TRACK, 5);
    if (clock != (int)on) groove_settings_midi(NARTI_TRACK, 5, (int)on - clock);
}

/* ------------------------------------------------------------ setup */
static COLD int ensure_track(void)
{
    if (groove_track_role(NARTI_TRACK) != GROOVE_TRACK_NORMAL) (void)groove_track_role_set(NARTI_TRACK, GROOVE_TRACK_NORMAL);
    for (unsigned t = 1; t < GROOVE_TRACKS; ++t)
        if (groove_track_role(t) != GROOVE_TRACK_OFF) (void)groove_track_role_set(t, GROOVE_TRACK_OFF);
    /* The host instrument stays silent: track 1 runs in MIDI-only mode and its
     * notes are routed to the FM-PLAITS voice by groove_midi_note(). */
    if (groove_source_set(NARTI_TRACK, GROOVE_PLUCK)) return -1;
    if (groove_arp_enabled(NARTI_TRACK)) groove_arp_set(NARTI_TRACK, 0);
    if (groove_sequence_length(NARTI_TRACK) != GROOVE_STEPS) groove_sequence_length_set(NARTI_TRACK, GROOVE_STEPS);
    /* A silent clock note on every 1/16: the FM1 sequencer becomes the master
     * clock (transport, tempo, swing, MIDI clock in/out). */
    struct groove_step cells[GROOVE_STEPS];
    for (unsigned s = 0; s < GROOVE_STEPS; ++s) { cells[s].note = 60; cells[s].velocity = 1; cells[s].drums = 0; }
    groove_sequence_replace(NARTI_TRACK, 0, cells, GROOVE_STEPS);
    int mode = (int)groove_midi_setting(NARTI_TRACK, 0);
    if (mode != 2) groove_settings_midi(NARTI_TRACK, 0, 2 - mode);
    return 0;
}
COLD int narti_start(unsigned fresh)
{
    if (!narti.ready) {
        memset(&narti, 0, sizeof narti);
        fpl_voice_init();
        narti.root = 9; narti.scale = 0; narti.density = 9; narti.length = 16;
        narti.accent = 25; narti.slide = 15; narti.spread = 55; narti.octave = 3;
        narti.engine = 0; narti.harmonics = 45; narti.timbre = 40; narti.morph = 35;
        narti.freq = 0; narti.lpg = 12;
        narti.mod_speed = 30; narti.mod_depth = 50;
        narti.speed = 4; narti.triplet = 0; narti.chance = 100;
        narti.rev_mix = 30; narti.rev_size = 70; narti.rev_decay = 60; narti.rev_tone = 35;
        narti.del_mix = 20; narti.del_div = 3; narti.del_fb = 45;
        memcpy(narti.live, &narti.harmonics, 3);
        fresh = 1;
    }
    int r = ensure_track();
    if (r) return r;
    narti.midi_out = (uint8_t)(fpl_midi_out != 0);
    if (fresh) {
        struct groove_view v = {0};
        groove_get_view(NARTI_TRACK, 0, &v);
        if (!v.clock_mode && v.tempo && v.tempo != 120) groove_tempo_edit(120 - (int)v.tempo);
        stir();
        seeds();
        history.valid = 0;
    }
    sound_push();
    groove_push();
    fpl.active = 1;
    render();
    narti.ready = 1;
    return 0;
}
void narti_stop_notes(void) {}

/* ------------------------------------------------------------ poll */
void narti_poll(uint32_t now)
{
    if (!narti.ready) return;
    if (narti.flash && (int32_t)(now - narti.flash_until) >= 0) narti.flash = 0;
    mod_poll(now);
    struct groove_view v = {0};
    groove_get_view(NARTI_TRACK, 0, &v);
    narti.playing = v.playing;
    fpl_seq.running = v.playing;
    if (v.tempo) fpl_fx.tempo = v.tempo;
    int step = fpl_seq_step;
    narti.play_step = (uint8_t)(step < 0 ? 0 : step);
    if (!v.playing || !was_playing) bars_mark = fpl_seq_bars;
    was_playing = v.playing;
    /* EVOLVE: mutate every 8 pattern loops. */
    if (narti.evolve && fpl_seq_bars - bars_mark >= 8U) { bars_mark = fpl_seq_bars; narti_mutate(2); }
}
