/* SPDX-License-Identifier: GPL-3.0-only WITH GPL-3.0-linking-exception
 * Generative FM-PLAITS flash budget switch (JieLi's current compiler makes
 * the original firmware fill the FM1 layout almost completely):
 *   0  everything kept (fits only with the exact r3 compiler)
 *   3  DX7 factory bank keeps its first 32 programs (of 128)
 *   4  DX7 factory bank keeps one program (FM-PLAITS does not use it)
 *   5  level 4 + FM-PLAITS only: the original editor pages are compiled out
 *      (screen.c IS()/GO()); FM-PLAITS, mixer (GLO), SAVE and Bluetooth stay.
 * tools/ci-build.ps1 sets the level and the SDK optimisation flag. */
#ifndef FPL_SIZE_H
#define FPL_SIZE_H
#define FPL_SIZE_LEVEL 0
#endif
