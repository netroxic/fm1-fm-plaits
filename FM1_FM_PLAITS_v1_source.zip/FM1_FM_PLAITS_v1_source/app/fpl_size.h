/* SPDX-License-Identifier: GPL-3.0-only WITH GPL-3.0-linking-exception
 * Generative FM-PLAITS flash budget switch. tools/ci-build.ps1 raises the
 * level only when the firmware does not fit the FM1 flash layout:
 *   0  normal build
 *   1  SDK build at -Os (patched by the CI script, nothing changes here)
 *   2  SDK build at -Oz
 *   3  -Oz and the DX7 factory bank keeps its first 32 programs (of 128) */
#ifndef FPL_SIZE_H
#define FPL_SIZE_H
#define FPL_SIZE_LEVEL 0
#endif
