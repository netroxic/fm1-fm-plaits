/* SPDX-License-Identifier: GPL-3.0-only WITH GPL-3.0-linking-exception
 * Generative FM-PLAITS for the M-VAVE FM1 — by @narti_live.
 *
 * One track: a Sting-style generative melody sequencer (FM1 track 1, played
 * through the FM1 sequencer for tempo/swing/clock) drives a Plaits-derived
 * voice (fpl_voice.c) through a low pass gate. No drums. Tracks 2-8 are off.
 * This module runs on the control task only. */
#ifndef NARTI_H
#define NARTI_H
#include <stdint.h>

enum { NARTI_TRACK = 0, NARTI_STEPS = 16, NARTI_SCALES = 8 };
enum { NP_SOUND, NP_SEQ, NP_GROOVE, NP_REVERB, NP_DELAY, NP_MENU, NARTI_PAGES };

struct narti_state {
    uint8_t ready, page;
    /* Generator: ranked steps (Sting style), so DENSITY is continuous. */
    uint8_t root, scale, density, length, accent, slide, spread, octave;
    uint8_t rank[NARTI_STEPS], note_r[NARTI_STEPS], oct_r[NARTI_STEPS];
    uint8_t acc_r[NARTI_STEPS], sld_r[NARTI_STEPS];
    uint8_t on[NARTI_STEPS], note[NARTI_STEPS], acc[NARTI_STEPS], sld[NARTI_STEPS];
    /* Sound: Plaits controls 0..100, FREQ in semitones, LPG -50..+50. */
    uint8_t engine, harmonics, timbre, morph;
    int8_t freq, lpg;                   /* freq in octaves -2..+2 */
    uint8_t live[3];                    /* H/T/M after the random LFO */
    uint8_t mod_on, mod_speed, mod_depth, evolve, midi_out;
    uint8_t speed, triplet, chance;                       /* speed 0..4 = /16 /8 /4 /2 X1 */
    uint8_t rev_mix, rev_size, rev_decay, rev_tone, del_mix, del_div, del_fb;
    uint8_t playing, play_step, flash;
    uint32_t flash_until;
};
extern struct narti_state narti;

const char *narti_scale_name(unsigned scale);
const char *narti_note_name(unsigned pitch_class);

int narti_start(unsigned fresh);
void narti_poll(uint32_t now);
void narti_stop_notes(void);

void narti_generate(void);
void narti_mutate(unsigned amount);
void narti_undo(void);
void narti_random_sound(void);
void narti_mod_toggle(void);
void narti_evolve_toggle(void);

enum { NG_ROOT, NG_SCALE, NG_DENSITY, NG_LENGTH, NG_SLIDE, NG_OCTAVE };
void narti_seq_edit(unsigned parameter, int delta);
enum { NS_HARMONICS, NS_TIMBRE, NS_MORPH, NS_FREQ };
void narti_sound_edit(unsigned parameter, int delta);
void narti_engine_edit(int delta);
void narti_lpg_edit(int delta);
enum { NM_SPEED, NM_DEPTH };
void narti_mod_edit(unsigned parameter, int delta);
void narti_midi_set(unsigned on);
enum { NQ_SPEED, NQ_TRIPLET, NQ_CHANCE, NQ_REV_MIX, NQ_REV_SIZE, NQ_REV_DECAY, NQ_REV_TONE, NQ_DEL_MIX, NQ_DEL_TIME, NQ_DEL_FB };
void narti_groove_edit(unsigned parameter, int delta);
void narti_transpose(unsigned key);
#endif
