/* SPDX-License-Identifier: GPL-3.0-only WITH GPL-3.0-linking-exception
 * Generative FM-PLAITS (FM1): tick-locked step sequencer — @narti_live.
 * Every FM1 1/16 tick (track 1 clock note) re-anchors the position, so the
 * generator follows the FM1 transport, swing and external MIDI clock, while
 * slower divisions and triplets are placed between ticks by sample counting.
 * Audio context only: SRAM code, no libc, no division by zero. */
#include "fm1.h"
#include "fpl_voice.h"
#include "fpl_audio.h"

#define AC FM1_AUDIO_CODE
struct fpl_seq_shared fpl_seq = {{0}, {0}, {0}, {0}, 16, 4, 0, 100, 0};
volatile int fpl_seq_step = -1;
volatile unsigned fpl_seq_bars;
extern volatile unsigned fpl_midi_out;

static FM1_AUDIO_DATA const float step_ticks[5] = {16.0f, 8.0f, 4.0f, 2.0f, 1.0f}; /* /16 /8 /4 /2 X1 */
static unsigned ticks, since_tick, interval = 5512U, started, was_running;
static float next_pos, last_len;
static int step = -1;
static uint32_t dice = 0x9e3779b9U;
static unsigned off_note = 255U, off_left, held_slide;

AC void fpl_clock_tick(void)
{
    if (!fpl_seq.running) return;
    if (!started) {
        started = 1; ticks = 0; since_tick = 0; next_pos = 0.0f; step = -1; last_len = 0.0f;
        return;
    }
    if (since_tick >= 256U && since_tick <= 176400U) interval = (interval + since_tick * 3U) / 4U;
    ++ticks;
    since_tick = 0;
}
static AC void note_off_now(void)
{
    if (off_note != 255U) { fpl_midi_emit(off_note, 0); off_note = 255U; }
}
AC void fpl_seq_block(void)
{
    if (!fpl_seq.running) {
        if (was_running) { note_off_now(); was_running = 0; }
        started = 0; step = -1; fpl_seq_step = -1;
        return;
    }
    was_running = 1;
    if (off_note != 255U) {
        if (off_left <= FM1_BLOCK_FRAMES) note_off_now();
        else off_left -= FM1_BLOCK_FRAMES;
    }
    if (!started) return;
    unsigned speed = fpl_seq.speed > 4U ? 4U : fpl_seq.speed;
    float len = step_ticks[speed] * (fpl_seq.triplet ? (2.0f / 3.0f) : 1.0f);
    float frac = (float)since_tick / (float)(interval ? interval : 1U);
    if (frac > 0.999f) frac = 0.999f;
    float pos = (float)ticks + frac;
    if (len != last_len) {
        /* New division: continue on its grid (anchored to the first tick). */
        if (last_len > 0.0f) next_pos = (float)((int)(pos / len) + 1) * len;
        last_len = len;
    }
    while (pos >= next_pos) {
        next_pos += len;
        int length = fpl_seq.length >= 1 && fpl_seq.length <= 16 ? fpl_seq.length : 16;
        step = step + 1 >= length ? 0 : step + 1;
        if (step == 0) ++fpl_seq_bars;
        fpl_seq_step = step;
        dice ^= dice << 13; dice ^= dice >> 17; dice ^= dice << 5;
        if (!fpl_seq.on[step] || (dice >> 8) % 100U >= fpl_seq.chance) continue;
        unsigned note = fpl_seq.note[step], accent = fpl_seq.acc[step], slide = fpl_seq.sld[step];
        fpl_note(note, (accent ? 120U : 84U) | (slide ? 1U : 0U));
        if (fpl_midi_out) {
            unsigned velocity = accent ? 120U : 84U;
            if (off_note != 255U && held_slide) { fpl_midi_emit(note, velocity); note_off_now(); }
            else { note_off_now(); fpl_midi_emit(note, velocity); }
            off_note = note;
            held_slide = slide;
            float gate = len * (float)interval * (slide ? 1.2f : 0.5f);
            off_left = gate < 64.0f ? 64U : (unsigned)gate;
        }
    }
    since_tick += FM1_BLOCK_FRAMES;
}
