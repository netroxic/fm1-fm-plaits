/* SPDX-License-Identifier: GPL-3.0-only WITH GPL-3.0-linking-exception
 * Generative FM-PLAITS (FM1) audio-side sequencer and effects — @narti_live.
 *
 * Clock: the FM1 sequencer plays a silent "clock" note on every 1/16 of
 * track 1 (MIDI-only mode). groove_midi_note() hands those ticks to
 * fpl_clock_tick(), so the generator follows the FM1 transport, tempo, swing
 * and external MIDI clock, and can divide (/2 .. /16) or play triplets in
 * between ticks. Control writes `fpl_seq`/`fpl_fx`; audio only reads them. */
#ifndef FPL_AUDIO_H
#define FPL_AUDIO_H
#include <stdint.h>

struct fpl_seq_shared {
    volatile uint8_t on[16], note[16], acc[16], sld[16];
    volatile uint8_t length, speed, triplet, chance, running;
};
extern struct fpl_seq_shared fpl_seq;
extern volatile int fpl_seq_step;       /* current step for the panel, -1 stopped */
extern volatile unsigned fpl_seq_bars;  /* pattern loops, for EVOLVE */

struct fpl_fx_shared {
    volatile float rev_mix, rev_size, rev_decay, rev_tone;   /* 0..1, decay 1 = FREEZE */
    volatile float del_mix, del_feedback, del_quarters;      /* time in quarter notes */
    volatile unsigned tempo;                                  /* BPM for the delay */
};
extern struct fpl_fx_shared fpl_fx;

/* Audio context. */
void fpl_clock_tick(void);
void fpl_seq_block(void);
void fpl_fx_run(const float *mono, float *left, float *right);   /* one block */
/* midi_router.c: note out on track 1's MIDI channel/ports (audio context). */
void fpl_midi_emit(unsigned note, unsigned velocity);
#endif
