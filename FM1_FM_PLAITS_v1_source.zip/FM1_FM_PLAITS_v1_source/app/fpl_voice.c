/* SPDX-License-Identifier: GPL-3.0-only WITH GPL-3.0-linking-exception
 * FM-PLAITS voice for the M-VAVE FM1 — Generative FM-PLAITS by @narti_live.
 *
 * The synthesis engines are C ports / adaptations of the algorithms in
 * Mutable Instruments Plaits:
 *
 *   Copyright 2016-2021 Emilie Gillet.
 *   Permission is hereby granted, free of charge, to any person obtaining a
 *   copy of this software and associated documentation files (the
 *   "Software"), to deal in the Software without restriction, including
 *   without limitation the rights to use, copy, modify, merge, publish,
 *   distribute, sublicense, and/or sell copies of the Software, and to permit
 *   persons to whom the Software is furnished to do so, subject to the
 *   following conditions: The above copyright notice and this permission
 *   notice shall be included in all copies or substantial portions of the
 *   Software. THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND.
 *
 * Everything that runs per sample lives in SRAM (FM1_AUDIO_CODE /
 * FM1_AUDIO_DATA) and calls no libc: the FM1 can program Flash while audio
 * runs. Tables are built once by fpl_voice_init() on the control task. */
#include "fm1.h"
#include "fpl_voice.h"
#ifndef FPL_SAMPLE_RATE_VARIABLE
#include "fpl_audio.h"
static float fx_dry[FM1_BLOCK_FRAMES], fx_l[FM1_BLOCK_FRAMES], fx_r[FM1_BLOCK_FRAMES];
#endif

#ifdef FPL_SAMPLE_RATE_VARIABLE /* Android app: the device chooses the rate */
extern float fpl_sample_rate;
#define SR fpl_sample_rate
#else
#define SR 44100.0f
#endif
#include "fpl_size.h"
#define AI static inline __attribute__((always_inline))
#define AC FM1_AUDIO_CODE
/* Medium helpers: one shared copy in SRAM (the FM1 flash budget is tight).
 * Audio code must never call into flash, so these are FM1_AUDIO_CODE too. */
#define AH static FM1_AUDIO_CODE
#define N FM1_BLOCK_FRAMES

struct fpl_params fpl = {0.5f, 0.5f, 0.5f, 0.0f, 0.0f, FPL_VA, 1};
volatile float fpl_scope[240];
volatile unsigned fpl_scope_ready;
volatile float fpl_env_view;
volatile unsigned fpl_midi_out; /* read by groove_midi_note() in audio context */

static const char *const names[FPL_ENGINES] = {
    "VA", "WAVESHAPE", "FM", "GRAIN", "ADDITIVE", "WAVETABLE", "CHORDS", "VOWEL",
    "SWARM", "NOISE", "PARTICLES", "STRING", "MODAL", "PHASE DIST", "TERRAIN", "CHIPTUNE"};
const char *fpl_engine_name(unsigned e) { return e < FPL_ENGINES ? names[e] : ""; }

/* ------------------------------------------------------------ tables (BSS) */
enum { WT_WAVES = 8, WT_SIZE = 256, DELAY = 2048, MODES = 16 };
static float sine_lut[1025];
static float wavetable[WT_WAVES][WT_SIZE + 1];

/* ------------------------------------------------------------ helpers */
AI float wrap1(float p) { return p - (float)(int)p; }          /* p >= 0 */
AI float clampf(float x, float lo, float hi) { return x < lo ? lo : x > hi ? hi : x; }
AI float lerp(float a, float b, float t) { return a + (b - a) * t; }
AI float fabsf_(float x) { return x < 0.0f ? -x : x; }
/* sin(2*pi*p) */
AH float fsin(float p)
{
    if (p < 0.0f) p += (float)(int)(-p) + 1.0f;
    p = wrap1(p) * 1024.0f;
    int i = (int)p;
    float f = p - (float)i;
    return sine_lut[i] + (sine_lut[i + 1] - sine_lut[i]) * f;
}
AH float fexp2(float x)
{
    x = clampf(x, -30.0f, 30.0f);
    int i = (int)x;
    if ((float)i > x) --i;
    float f = x - (float)i;
    union { float f; int32_t i; } u;
    u.f = 1.0f + f * (0.6951786f + f * (0.2262058f + f * 0.0782133f));
    u.i += (int32_t)((uint32_t)i << 23);
    return u.f;
}
AI float semis(float s) { return fexp2(s * (1.0f / 12.0f)); }
AH float soft(float x)
{
    x = clampf(x, -3.0f, 3.0f);
    return x * (27.0f + x * x) / (27.0f + 9.0f * x * x);
}
AH float blep(float t, float dt)
{
    if (t < dt) { t /= dt; return t + t - t * t - 1.0f; }
    if (t > 1.0f - dt) { t = (t - 1.0f) / dt; return t * t + t + t + 1.0f; }
    return 0.0f;
}
static uint32_t rng_state = 0x2545f491U;
AH float noise(void)
{
    rng_state ^= rng_state << 13; rng_state ^= rng_state >> 17; rng_state ^= rng_state << 5;
    return (float)(int32_t)rng_state * 4.6566129e-10f;
}
AI float unoise(void) { return noise() * 0.5f + 0.5f; }

struct svf { float g, r, h, s1, s2; };
AH void svf_set(struct svf *f, float freq, float q)
{
    freq = clampf(freq, 0.00002f, 0.497f);
    float g = fsin(freq * 0.5f) / fsin(freq * 0.5f + 0.25f); /* tan(pi f) */
    f->g = g; f->r = 1.0f / q; f->h = 1.0f / (1.0f + f->r * g + g * g);
}
/* Returns band-pass; low/high through pointers when wanted. */
AH float svf_run(struct svf *f, float in, float *lp, float *hp)
{
    float h = (in - (f->r + f->g) * f->s1 - f->s2) * f->h;
    float bp = f->g * h + f->s1;
    f->s1 = f->g * h + bp;
    float l = f->g * bp + f->s2;
    f->s2 = f->g * bp + l;
    if (lp) *lp = l;
    if (hp) *hp = h;
    return bp;
}

/* ------------------------------------------------------------ voice state */
static struct vstate {
    float ph[16], aux[16];
    struct svf f[MODES];
    float delay[DELAY];
    unsigned dw;
    float lp, lp2, fb, sh, clk, hp_state, hp_in;
    unsigned arp, arp_count;
    float excite; unsigned burst;
    int engine;
} st;
static float buf[N];
static float h_s = 0.5f, t_s = 0.5f, m_s = 0.5f;
static float note_cur = 48.0f, note_target = 48.0f;
static unsigned trig, legato_next, glide;
static float accent = 0.8f;
/* LPG */
static float env, env_peak = 1.0f, lpg1, lpg2;
static unsigned env_stage = 2;
/* scope */
static unsigned scope_n, scope_decim, scope_count, scope_armed;
static float scope_prev;

/* ------------------------------------------------------------ engines
 * Each renders N mono samples into buf at normalized frequency f0. */
static AC void e_va(float f0)
{
    float f1 = f0, f2 = clampf(f0 * semis((h_s - 0.5f) * 48.0f), 0.0f, 0.45f);
    float shape = t_s < 0.5f ? t_s * 2.0f : 1.0f, pw = t_s < 0.5f ? 0.5f : 0.5f + (t_s - 0.5f) * 0.9f;
    for (unsigned i = 0; i < N; ++i) {
        float o[2];
        for (unsigned k = 0; k < 2; ++k) {
            float dt = k ? f2 : f1, p = st.ph[k] = wrap1(st.ph[k] + dt);
            float saw = 2.0f * p - 1.0f - blep(p, dt);
            float q = wrap1(p - pw + 1.0f);
            float sq = (p < pw ? 1.0f : -1.0f) + blep(p, dt) - blep(q, dt);
            o[k] = lerp(saw, sq, shape);
        }
        buf[i] = (o[0] * (1.0f - m_s * 0.6f) + o[1] * m_s) * 0.45f;
    }
}
static AC void e_wshp(float f0)
{
    float amount = 1.0f + t_s * t_s * 9.0f, bias = (m_s - 0.5f) * 1.6f;
    for (unsigned i = 0; i < N; ++i) {
        float p = st.ph[0] = wrap1(st.ph[0] + f0);
        float tri = 1.0f - 4.0f * fabsf_(p - 0.5f);
        float x = tri * amount + bias;
        float sine_fold = fsin(x * 0.25f), tanh_shape = soft(x);
        float tri_fold = 1.0f - 4.0f * fabsf_(wrap1(x * 0.25f + 64.25f) - 0.5f);
        float y = h_s < 0.5f ? lerp(tanh_shape, sine_fold, h_s * 2.0f) : lerp(sine_fold, tri_fold, (h_s - 0.5f) * 2.0f);
        st.lp += (y - st.lp) * 0.7f;
        buf[i] = st.lp * 0.5f;
    }
}
static FM1_AUDIO_DATA const float fm_ratios[12] = {0.5f, 1.0f, 1.5f, 2.0f, 2.5f, 3.0f, 3.5f, 4.0f, 5.0f, 6.0f, 7.0f, 9.0f};
static AC void e_fm(float f0)
{
    float ratio = fm_ratios[(int)(h_s * 11.99f)];
    float index = t_s * t_s * 2.5f;
    float fbm = m_s > 0.5f ? (m_s - 0.5f) * 0.6f : 0.0f, fbc = m_s < 0.5f ? (0.5f - m_s) * 0.5f : 0.0f;
    for (unsigned i = 0; i < N; ++i) {
        st.ph[0] = wrap1(st.ph[0] + f0);
        st.ph[1] = wrap1(st.ph[1] + clampf(f0 * ratio, 0.0f, 0.49f));
        float mod = fsin(st.ph[1] + fbm * st.aux[0]);
        st.aux[0] = mod;
        float car = fsin(st.ph[0] + index * mod + fbc * st.aux[1]);
        st.aux[1] = car;
        buf[i] = car * 0.5f;
    }
}
static AC void e_grain(float f0)
{
    /* Grainlet / VOSIM style formant oscillator: windowed carriers reset by f0. */
    float r1 = semis(t_s * 60.0f), r2 = semis(h_s * 60.0f) * 1.5f;
    for (unsigned i = 0; i < N; ++i) {
        float p = st.ph[0] + f0;
        if (p >= 1.0f) p -= 1.0f;
        st.ph[0] = p;
        float w1 = 1.0f - p, w2 = w1 * w1;
        float win = lerp(w1, w2 * w2, m_s);
        float s = fsin(p * r1) + 0.6f * fsin(p * r2);
        buf[i] = s * win * 0.45f;
    }
}
static AC void e_add(float f0)
{
    float centre = t_s * 15.0f, width = 0.6f + h_s * h_s * 8.0f, amp[16], total = 0.0f;
    for (unsigned k = 0; k < 16; ++k) {
        float d = ((float)k - centre) / width, a = 1.0f / (1.0f + d * d * d * d);
        if ((k & 1U) == 1U) a *= clampf(2.0f - m_s * 2.0f, 0.0f, 1.0f); /* even harmonics */
        else if (k) a *= clampf(m_s * 2.0f, 0.0f, 1.0f);                 /* odd above the fundamental */
        if (f0 * (float)(k + 1) > 0.45f) a = 0.0f;
        amp[k] = a; total += a;
    }
    float norm = total > 0.0f ? 0.6f / (total > 1.0f ? total * 0.6f + 0.4f : 1.0f) : 0.0f;
    for (unsigned i = 0; i < N; ++i) {
        float s = 0.0f;
        for (unsigned k = 0; k < 16; ++k) {
            st.ph[k] = wrap1(st.ph[k] + f0 * (float)(k + 1));
            if (amp[k] > 0.0f) s += fsin(st.ph[k]) * amp[k];
        }
        buf[i] = s * norm;
    }
}
static AC void e_wtbl(float f0)
{
    float pos = t_s * (WT_WAVES - 1.001f);
    int a = (int)pos;
    float x = pos - (float)a, warp = (m_s - 0.5f) * 1.6f;
    for (unsigned i = 0; i < N; ++i) {
        float p = st.ph[0] = wrap1(st.ph[0] + f0);
        /* phase warp (morph) */
        float q = p + warp * p * (1.0f - p);
        q = clampf(q, 0.0f, 0.9999f) * WT_SIZE;
        int k = (int)q;
        float fr = q - (float)k;
        float w0 = lerp(wavetable[a][k], wavetable[a][k + 1], fr);
        float w1 = lerp(wavetable[a + 1][k], wavetable[a + 1][k + 1], fr);
        float w = lerp(w0, w1, x);
        int ra = WT_WAVES - 1 - a;
        float v = lerp(wavetable[ra][k], wavetable[ra][k + 1], fr);
        float y = lerp(w, v, h_s);
        st.lp += (y - st.lp) * clampf(0.25f + (1.0f - f0 * 8.0f), 0.2f, 1.0f);
        buf[i] = st.lp * 0.5f;
    }
}
static FM1_AUDIO_DATA const int8_t chords[11][4] = {
    {0, 12, 19, 24}, {0, 7, 12, 19}, {0, 5, 7, 12}, {0, 3, 7, 12}, {0, 3, 7, 10}, {0, 3, 10, 14},
    {0, 3, 10, 17}, {0, 2, 9, 16}, {0, 4, 11, 14}, {0, 4, 7, 11}, {0, 4, 7, 12}};
static AC void e_chord(float f0)
{
    const int8_t *c = chords[(int)(h_s * 10.99f)];
    unsigned inv = (unsigned)(t_s * 3.99f);
    float fr[4];
    for (unsigned v = 0; v < 4; ++v) fr[v] = clampf(f0 * semis((float)c[v] + (v < inv ? 12.0f : 0.0f) - 12.0f), 0.0f, 0.45f);
    float sq = m_s < 0.5f ? m_s * 2.0f : 1.0f, organ = m_s > 0.5f ? (m_s - 0.5f) * 2.0f : 0.0f;
    for (unsigned i = 0; i < N; ++i) {
        float s = 0.0f;
        for (unsigned v = 0; v < 4; ++v) {
            float dt = fr[v], p = st.ph[v] = wrap1(st.ph[v] + dt);
            float saw = 2.0f * p - 1.0f - blep(p, dt);
            float q = wrap1(p + 0.5f);
            float square = (p < 0.5f ? 1.0f : -1.0f) + blep(p, dt) - blep(q, dt);
            float o = lerp(saw, square, sq);
            if (organ > 0.0f) o = lerp(o, fsin(p) + 0.5f * fsin(p * 2.0f), organ);
            s += o;
        }
        buf[i] = s * 0.18f;
    }
}
static FM1_AUDIO_DATA const float vowels[5][3] = {
    {730.0f, 1090.0f, 2440.0f}, {530.0f, 1840.0f, 2480.0f}, {270.0f, 2290.0f, 3010.0f},
    {570.0f, 840.0f, 2410.0f}, {300.0f, 870.0f, 2240.0f}};
static FM1_AUDIO_DATA const float vowel_amp[3] = {1.0f, 0.55f, 0.3f};
static AC void e_vowel(float f0)
{
    float v = t_s * 3.999f, x = v - (float)(int)v, size = semis((h_s - 0.5f) * 14.0f);
    const float *a = vowels[(int)v], *b = vowels[(int)v + 1];
    for (unsigned k = 0; k < 3; ++k) svf_set(&st.f[k], lerp(a[k], b[k], x) * size / SR, 6.0f + (float)k * 3.0f);
    for (unsigned i = 0; i < N; ++i) {
        float p = st.ph[0] = wrap1(st.ph[0] + f0);
        float g = 1.0f - p; g = g * g * g * g; g -= 0.2f;      /* glottal pulse */
        float e = lerp(g, noise() * 0.6f, m_s);
        float s = 0.0f;
        for (unsigned k = 0; k < 3; ++k) s += svf_run(&st.f[k], e, 0, 0) * vowel_amp[k];
        buf[i] = soft(s * 0.8f) * 0.6f;
    }
}
static AC void e_swarm(float f0)
{
    float spread = h_s * h_s * 12.0f, rate = t_s;
    for (unsigned v = 0; v < 8; ++v) {
        float off = ((float)v - 3.5f) / 3.5f * spread + st.aux[8 + v];
        st.aux[8 + v] += (noise() * 0.05f - st.aux[8 + v] * 0.02f);  /* slow drift */
        st.aux[v] = clampf(f0 * semis(off), 0.0f, 0.45f);
        if (rate < 0.95f && unoise() < rate * rate * 0.08f + 0.002f) st.ph[8 + v] = 1.0f; /* grain burst */
    }
    for (unsigned i = 0; i < N; ++i) {
        float s = 0.0f;
        for (unsigned v = 0; v < 8; ++v) {
            float dt = st.aux[v], p = st.ph[v] = wrap1(st.ph[v] + dt);
            float saw = 2.0f * p - 1.0f - blep(p, dt);
            float o = lerp(saw, fsin(p), m_s);
            float e = rate >= 0.95f ? 1.0f : (st.ph[8 + v] *= 0.9997f);
            s += o * e;
        }
        buf[i] = s * 0.3f;
    }
}
static AC void e_noise(float f0)
{
    float clock = clampf(f0 * semis((t_s - 0.5f) * 96.0f) * 4.0f, 0.0f, 1.0f);
    svf_set(&st.f[0], clampf(f0, 0.0f, 0.45f), 0.5f + m_s * m_s * 40.0f);
    float gain = 1.0f / (1.0f + m_s * m_s * 6.0f);
    for (unsigned i = 0; i < N; ++i) {
        st.clk += clock;
        if (st.clk >= 1.0f) { st.clk -= 1.0f; st.sh = noise(); }
        float in = clock >= 1.0f ? noise() : st.sh, lp, hp;
        float bp = svf_run(&st.f[0], in, &lp, &hp);
        float y = h_s < 0.5f ? lerp(lp, bp, h_s * 2.0f) : lerp(bp, hp, (h_s - 0.5f) * 2.0f);
        buf[i] = soft(y * gain) * 0.6f;
    }
}
static AC void e_particle(float f0)
{
    float density = t_s * t_s * 0.02f + 0.0002f, spread = 48.0f * h_s * h_s;
    float q = m_s >= 0.5f ? 1.0f + semis((m_s - 0.5f) * 72.0f) : 1.0f + m_s * 2.0f;
    for (unsigned i = 0; i < N; ++i) {
        float in = (i & 1U) ? 1e-9f : -1e-9f;
        if (unoise() < density) {
            in = noise() * 2.0f;
            float f = clampf(f0 * semis(spread * noise()), 0.0001f, 0.45f);
            svf_set(&st.f[0], f, q);
            svf_set(&st.f[1], clampf(f * 1.5f, 0.0001f, 0.45f), q);
        }
        float s = svf_run(&st.f[0], in, 0, 0) + 0.5f * svf_run(&st.f[1], in, 0, 0);
        buf[i] = soft(s * 2.5f) * 0.8f;
    }
}
static AC void e_string(float f0)
{
    /* Karplus-Strong with stiffness (dispersion) and brightness-dependent loss. */
    float length = clampf(1.0f / f0, 4.0f, (float)(DELAY - 4));
    float bright = 0.15f + t_s * 0.8f, decay = 1.0f - (1.0f - m_s) * (1.0f - m_s) * 0.05f;
    float ap = (h_s - 0.5f) * 1.2f;
    if (trig) { st.burst = (unsigned)length; st.excite = 0.0f; }
    for (unsigned i = 0; i < N; ++i) {
        float x = (i & 1U) ? 1e-9f : -1e-9f;
        if (st.burst) { --st.burst; st.excite += (noise() - st.excite) * bright; x = st.excite * 1.2f; }
        float rp = (float)st.dw - length + (float)DELAY;
        int r = (int)rp;
        float fr = rp - (float)r;
        float a = st.delay[(unsigned)r & (DELAY - 1)], b = st.delay[(unsigned)(r + 1) & (DELAY - 1)];
        float y = lerp(a, b, fr);
        st.lp += (y - st.lp) * (0.3f + bright * 0.7f);
        float d = ap * (st.lp - st.aux[0]) + st.aux[1]; /* 1st order allpass */
        st.aux[1] = st.lp; st.aux[0] = d;
        st.delay[st.dw] = d * decay + x;
        st.dw = (st.dw + 1) & (DELAY - 1);
        buf[i] = y * 0.8f;
    }
}
static FM1_AUDIO_DATA const float stiffness_lut[17] = {
    -0.0625f, -0.0469f, -0.0312f, -0.0156f, 0.0f, 0.001f, 0.0078f, 0.0188f, 0.0366f,
    0.0654f, 0.1119f, 0.1872f, 0.309f, 0.5059f, 0.8246f, 1.048f, 2.0f};
static AC void e_modal(float f0)
{
    /* Mode bank after Plaits' Resonator: stretched partials, Q from damping. */
    float s = h_s * 15.999f;
    float stiffness = lerp(stiffness_lut[(int)s], stiffness_lut[(int)s + 1], s - (float)(int)s);
    float q_sqrt = semis(m_s * 79.7f * 0.75f), q = 500.0f * q_sqrt * q_sqrt * 0.02f;
    float bright = t_s * (1.0f - h_s * 0.3f) * (1.0f - m_s * 0.3f);
    float q_loss = bright * (2.0f - bright) * 0.85f + 0.15f;
    float harmonic = f0, stretch = 1.0f;
    for (unsigned k = 0; k < MODES; ++k) {
        float fm = clampf(harmonic * stretch, 0.0f, 0.497f);
        svf_set(&st.f[k], fm, 1.0f + fm * q * 50.0f);
        st.aux[k] = fsin(0.31f * (float)k + 0.25f) * 0.25f * (1.0f - fm * 2.0f);
        stretch += stiffness;
        stiffness *= stiffness < 0.0f ? 0.93f : 0.98f;
        harmonic += f0;
        q *= q_loss;
    }
    if (trig) { st.burst = 64; st.excite = 1.0f; }
    for (unsigned i = 0; i < N; ++i) {
        float x = (i & 1U) ? 1e-9f : -1e-9f; /* keeps the mode filters out of denormals */
        if (st.burst) { --st.burst; x = st.excite + noise() * bright * 0.5f; st.excite *= 0.5f; }
        float out = 0.0f;
        for (unsigned k = 0; k < MODES; ++k) out += svf_run(&st.f[k], x, 0, 0) * st.aux[k];
        buf[i] = soft(out * 2.0f) * 0.7f;
    }
}
static AC void e_pd(float f0)
{
    /* Casio-style phase distortion with a synced resonant mode on MORPH. */
    float knee = 0.5f - t_s * 0.49f, ratio = 1.0f + h_s * 7.0f;
    for (unsigned i = 0; i < N; ++i) {
        float p = st.ph[0] + f0;
        if (p >= 1.0f) p -= 1.0f;
        st.ph[0] = p;
        float w = p < knee ? 0.5f * p / knee : 0.5f + 0.5f * (p - knee) / (1.0f - knee);
        float cz = fsin(w + 0.25f);
        float res = fsin(p * ratio * (1.0f + t_s * 3.0f)) * (1.0f - p);
        buf[i] = lerp(cz, res, m_s) * 0.5f;
    }
}
static AC void e_terrain(float f0)
{
    float radius = 0.15f + t_s * 0.85f, cx = (m_s - 0.5f) * 1.4f, cy = (m_s - 0.5f) * -0.9f;
    for (unsigned i = 0; i < N; ++i) {
        float p = st.ph[0] = wrap1(st.ph[0] + f0);
        float x = cx + radius * fsin(p + 0.25f), y = cy + radius * fsin(p);
        float z0 = fsin(x * 0.5f) * fsin(y * 0.5f + 0.25f);
        float z1 = fsin((x * x + y * y) * 0.5f);
        float z2 = fsin(x * 0.5f + 0.4f * fsin(y * 0.75f));
        float z3 = soft(3.0f * x * y);
        float hh = h_s * 2.999f;
        int k = (int)hh;
        float fr = hh - (float)k;
        float za = k == 0 ? z0 : k == 1 ? z1 : z2, zb = k == 0 ? z1 : k == 1 ? z2 : z3;
        float z = lerp(za, zb, fr);
        /* DC blocker */
        float out = z - st.hp_in + 0.995f * st.hp_state;
        st.hp_in = z; st.hp_state = out;
        buf[i] = out * 0.55f;
    }
}
static FM1_AUDIO_DATA const int8_t arps[6][4] = {{0, 0, 0, 0}, {0, 12, 0, 12}, {0, 4, 7, 12}, {0, 3, 7, 12}, {0, 7, 12, 19}, {0, 4, 7, 11}};
static AC void e_chip(float f0)
{
    float duty = t_s < 0.33f ? 0.125f : t_s < 0.66f ? 0.25f : 0.5f;
    const int8_t *arp = arps[(int)(h_s * 5.99f)];
    if (trig) { st.arp = 0; st.arp_count = 0; }
    for (unsigned i = 0; i < N; ++i) {
        if ((float)++st.arp_count >= SR * (1.0f / 60.0f)) { st.arp_count = 0; st.arp = (st.arp + 1) & 3U; } /* 60 Hz frames */
        float dt = clampf(f0 * semis((float)arp[st.arp]), 0.0f, 0.45f);
        float p = st.ph[0] = wrap1(st.ph[0] + dt);
        float pulse = p < duty ? 1.0f : -1.0f;
        float tri = 1.0f - 4.0f * fabsf_(p - 0.5f);
        tri = (float)(int)(tri * 7.5f + 8.0f) / 7.5f - 1.0666f; /* 4-bit steps */
        buf[i] = lerp(pulse * 0.6f, tri, m_s) * 0.45f;
    }
}

/* ------------------------------------------------------------ control side */
/* sin(2*pi*t) without libm (the FM1 firmware links no math library).
 * Folds t to [-0.25, 0.25] turns, then a Taylor series to x^11: error < 1e-7. */
static float sin_turns(float t)
{
    int n = (int)(t + (t >= 0.0f ? 0.5f : -0.5f));
    t -= (float)n;                                   /* [-0.5, 0.5] */
    if (t > 0.25f) t = 0.5f - t;
    else if (t < -0.25f) t = -0.5f - t;
    float x = 6.2831853f * t, x2 = x * x;
    return x * (1.0f - x2 / 6.0f * (1.0f - x2 / 20.0f * (1.0f - x2 / 42.0f * (1.0f - x2 / 72.0f * (1.0f - x2 / 110.0f)))));
}
void fpl_voice_init(void)
{
    for (unsigned i = 0; i <= 1024; ++i) sine_lut[i] = sin_turns((float)i / 1024.0f);
    /* Procedural wavetables: sine, 2nd, triangle, saw, square, pulse, formant, bell. */
    for (unsigned w = 0; w < WT_WAVES; ++w) {
        float peak = 0.0f;
        for (unsigned i = 0; i <= WT_SIZE; ++i) {
            float p = (float)(i % WT_SIZE) / WT_SIZE, s = 0.0f;
            for (unsigned k = 1; k <= 24; ++k) {
                float a = 0.0f, fk = (float)k;
                switch (w) {
                case 0: a = k == 1 ? 1.0f : 0.0f; break;
                case 1: a = k == 1 ? 1.0f : k == 2 ? 0.6f : k == 3 ? 0.2f : 0.0f; break;
                case 2: a = (k & 1U) ? ((k & 2U) ? -1.0f : 1.0f) / (fk * fk) : 0.0f; break;
                case 3: a = 1.0f / fk; break;
                case 4: a = (k & 1U) ? 1.0f / fk : 0.0f; break;
                case 5: a = 1.0f / (1.0f + 0.05f * fk * fk); break;
                case 6: a = 1.0f / (1.0f + (fk - 7.0f) * (fk - 7.0f) * 0.4f); break;
                default: a = (k == 1 || k == 3 || k == 6 || k == 11 || k == 17) ? 2.0f / fk : 0.0f; break;
                }
                s += a * sin_turns(fk * p);
            }
            wavetable[w][i] = s;
            if (fabsf_(s) > peak) peak = fabsf_(s);
        }
        for (unsigned i = 0; i <= WT_SIZE; ++i) wavetable[w][i] /= peak > 0.0f ? peak : 1.0f;
    }
}

/* ------------------------------------------------------------ audio side */
static AC void fill_zero(volatile float *p, unsigned n)
{
    for (unsigned i = 0; i < n; ++i) p[i] = 0.0f;
}
static AC void reset_engine(int e)
{
    /* Volatile stores keep the compiler from emitting a libc memset call. */
    fill_zero(st.ph, 16);
    fill_zero(st.aux, 16);
    fill_zero((volatile float *)st.f, MODES * (unsigned)(sizeof(struct svf) / sizeof(float)));
    fill_zero(st.delay, DELAY);
    volatile struct vstate *v = &st;
    v->lp = 0.0f; v->lp2 = 0.0f; v->fb = 0.0f; v->sh = 0.0f; v->clk = 0.0f;
    v->hp_state = 0.0f; v->hp_in = 0.0f; v->excite = 0.0f;
    v->burst = 0; v->arp = 0; v->arp_count = 0;
    v->engine = e;
}
AC void fpl_note(unsigned note, unsigned velocity)
{
    if (!velocity || note > 127) return; /* the LPG is triggered, not gated */
    float n = (float)note;
    unsigned legato = legato_next && env_stage != 2;
    legato_next = velocity & 1U;   /* odd velocity: slide into the next note */
    accent = velocity >= 100 ? 1.0f : 0.72f;
    note_target = n;
    if (legato) { glide = 1; return; }
    note_cur = n; glide = 0;
    trig = 1;
    env_stage = 0;
    env_peak = accent;
}
AC void fpl_render_add(int32_t *out)
{
    int e = fpl.engine;
    if (e < 0 || e >= FPL_ENGINES) e = 0;
    if (e != st.engine) reset_engine(e);
    h_s += (fpl.harmonics - h_s) * 0.35f;
    t_s += (fpl.timbre - t_s) * 0.35f;
    m_s += (fpl.morph - m_s) * 0.35f;
    if (glide) note_cur += (note_target - note_cur) * 0.12f;
    else note_cur = note_target;
    float f0 = clampf(440.0f / SR * semis(note_cur + fpl.transpose - 69.0f), 0.00005f, 0.45f);
    /* LPG timing from ALGORITHM: centre = pluck, CW = longer decay, CCW = slow attack. */
    float lpg = clampf(fpl.lpg, -1.0f, 1.0f);
    float attack_s = lpg < 0.0f ? 0.002f * fexp2(-lpg * 10.0f) : 0.0015f;
    float decay_s = lpg >= 0.0f ? 0.07f * fexp2(lpg * 6.5f) : 0.35f - lpg * 1.4f;
    float attack_inc = 1.0f / (attack_s * SR);
    float decay_k = 1.0f - 6.9f / (decay_s * SR);
    /* If-chain, not a switch: a jump table would live in Flash. */
    if (e == FPL_VA) e_va(f0);
    else if (e == FPL_WSHP) e_wshp(f0);
    else if (e == FPL_FM) e_fm(f0);
    else if (e == FPL_GRAIN) e_grain(f0);
    else if (e == FPL_ADD) e_add(f0);
    else if (e == FPL_WTBL) e_wtbl(f0);
    else if (e == FPL_CHORD) e_chord(f0);
    else if (e == FPL_VOWEL) e_vowel(f0);
    else if (e == FPL_SWARM) e_swarm(f0);
    else if (e == FPL_NOISE) e_noise(f0);
    else if (e == FPL_PRTCL) e_particle(f0);
    else if (e == FPL_STRING) e_string(f0);
    else if (e == FPL_MODAL) e_modal(f0);
    else if (e == FPL_PD) e_pd(f0);
    else if (e == FPL_TERRAIN) e_terrain(f0);
    else e_chip(f0);
    trig = 0;
    /* Physical models ring on their own: the LPG only colours them a little. */
    unsigned ringing = e == FPL_STRING || e == FPL_MODAL || e == FPL_PRTCL;
    float active = fpl.active ? 1.0f : 0.0f;
    for (unsigned i = 0; i < N; ++i) {
        if (env_stage == 0) {
            env += attack_inc * env_peak;
            if (env >= env_peak) { env = env_peak; env_stage = 1; }
        } else if (env_stage == 1) {
            env *= decay_k;
            if (env < 0.0001f) { env = 0.0f; env_stage = 2; }
        }
        float level = ringing ? clampf(env * 1.6f + 0.25f * env_peak, 0.0f, 1.0f) : env;
        /* Low pass gate: cutoff and gain follow the envelope together. */
        float fc = 60.0f / SR * fexp2(level * 8.5f);
        float c = fc * 6.2831853f / (1.0f + fc * 6.2831853f);
        lpg1 += (buf[i] + ((i & 1U) ? 1e-9f : -1e-9f) - lpg1) * c;
        lpg2 += (lpg1 - lpg2) * c;
        float y = lpg2 * level * active;
        buf[i] = y;
#ifdef FPL_SAMPLE_RATE_VARIABLE /* Android app: its own float FX follow */
        int32_t v = (int32_t)(soft(y * 2.0f) * 0.7f * 8388607.0f);
        out[2 * i] += v;
        out[2 * i + 1] += v;
#else
        fx_dry[i] = soft(y * 2.0f) * 0.7f;
#endif
    }
#ifndef FPL_SAMPLE_RATE_VARIABLE
    /* FM1: synced ping-pong delay + black-hole reverb, then the output stage. */
    fpl_fx_run(fx_dry, fx_l, fx_r);
    for (unsigned i = 0; i < N; ++i) {
        out[2 * i] += (int32_t)(soft(fx_l[i] * 1.1f) * 0.9f * 8388607.0f);
        out[2 * i + 1] += (int32_t)(soft(fx_r[i] * 1.1f) * 0.9f * 8388607.0f);
    }
#endif
    fpl_env_view = env;
    /* Scope: capture 240 points from a rising zero crossing, ~2 periods wide. */
    if (!fpl_scope_ready && (env > 0.05f || scope_armed)) {
        if (!scope_armed) {
            float period = 1.0f / f0;
            scope_decim = (unsigned)(period * 2.0f / 240.0f) + 1U;
            scope_armed = 1; scope_n = scope_count = 0;
        }
        for (unsigned i = 0; i < N && scope_armed; ++i) {
            float s = buf[i];
            if (scope_armed == 1) {
                if (scope_prev <= 0.0f && s > 0.0f) scope_armed = 2;
                else if (++scope_count > 4096U) scope_armed = 2;
            }
            if (scope_armed == 2 && ++scope_count >= scope_decim) {
                scope_count = 0;
                fpl_scope[scope_n++] = s;
                if (scope_n >= 240) { fpl_scope_ready = 1; scope_armed = 0; }
            }
            scope_prev = s;
        }
    }
}
