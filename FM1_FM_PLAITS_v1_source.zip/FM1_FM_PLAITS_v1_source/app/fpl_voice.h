/* SPDX-License-Identifier: GPL-3.0-only WITH GPL-3.0-linking-exception
 * FM-PLAITS voice: synthesis engines ported to C from Mutable Instruments
 * Plaits (Copyright 2016-2021 Emilie Gillet, MIT license; see fpl_voice.c),
 * followed by a low pass gate. One monophonic voice, mixed after the FM1
 * engine in fm1_output_mix(). Part of Generative FM-PLAITS by @narti_live. */
#ifndef FPL_VOICE_H
#define FPL_VOICE_H
#include <stdint.h>

enum {
    FPL_VA, FPL_WSHP, FPL_FM, FPL_GRAIN, FPL_ADD, FPL_WTBL, FPL_CHORD, FPL_VOWEL,
    FPL_SWARM, FPL_NOISE, FPL_PRTCL, FPL_STRING, FPL_MODAL, FPL_PD, FPL_TERRAIN, FPL_CHIP,
    FPL_ENGINES
};
/* Written by the control task, read once per audio block. */
struct fpl_params {
    volatile float harmonics, timbre, morph; /* 0..1 */
    volatile float transpose;                /* semitones, the FREQ knob */
    volatile float lpg;                      /* -1 slow attack .. 0 pluck .. +1 long decay */
    volatile int engine;
    volatile int active;                     /* 0 silences the voice */
};
extern struct fpl_params fpl;

/* Scope: 240 points of the voice, phase-aligned. The audio side fills it when
 * `fpl_scope_ready` is 0; the panel reads it and clears the flag. */
extern volatile float fpl_scope[240];
extern volatile unsigned fpl_scope_ready;
extern volatile float fpl_env_view; /* current LPG level, for the panel */

const char *fpl_engine_name(unsigned engine);
void fpl_voice_init(void); /* control task, before audio needs it */
/* Audio context (called from the sequencer's MIDI hook and the output mixer). */
void fpl_note(unsigned note, unsigned velocity);
void fpl_render_add(int32_t *stereo_q23);
#endif
